<html>
    <head>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
        <script type="text/javascript" src="Compilar.js"></script>
        

    </head>
    <body>
      <div>
      <div id="Archivos">
            Aquí se imprimirá la respuesta
      </div>
        <div id="Sujerencia">
            Aquí se imprimirá la respuesta
      </div>
        <h1> Clase </h1>
       <textarea type="text" id="calsep" ></textarea>
     
        <h1> codigo </h1>
      <textarea type="text" id="Programa"  ></textarea>
        <button id="Programar" value="2">programar</button>
         <button id="Guardar" value="2">Guardar</button>
            <button id="Compila" value="3">Compilar</button>
        <FORM NAME="formulario" >
   <input type='file' name='ARCHIVO' id='ARCHIVO' />

   </FORM>
      <div id="respuesta">
            Aquí se imprimirá la respuesta
      </div> 
    </body>
</html>
