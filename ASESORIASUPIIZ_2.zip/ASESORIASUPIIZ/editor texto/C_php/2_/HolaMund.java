public class HolaMund {

public static void main(String[] args) { 

HolaMundo h = new HolaMundo();

h.hola();

}

}








