$(function () {

    function siRespuesta(r) {
        $('#respuesta')
            .html(r); // Mostrar la respuesta del servidor en el div con el id "respuesta"
    }

    function siRespuesta2(r) {
        $('#respuesta1')
            .html(r); // Mostrar la respuesta del servidor en el div con el id "respuesta"
    }

    function siRespuesta1(r) {
        $('#Archivos')
            .html(r); // Mostrar los archivos
    }

    function siError(e) {
        alert('Ocurrió un error al realizar la petición: ' + e.statusText);
    }



    function programar(e) { // creamos la carpeta en donde se guardara las clases
        var programa = $('#Programar').val();
        var parametros = {variable1: programa};
        var post = $.post(
            "programar.php"
            , parametros
            , siRespuesta
            , 'html'
        );



        post.error(siError);
    }

    function Guardar(e) { //guardamos y editamos los las clases del proyecto del usuario
        var NombreA = $('#Nombre').val();
        var programa = $('#Programa').val();
        var carpeta = $('#Guardar').val();
        var parametros = {
            Nombre: NombreA
            , programa: programa
            , carpeta: carpeta
        };

        var post = $.post(
            "guardar.php"
            , parametros
            , siRespuesta
            , 'html'

        );



        post.error(siError);
    }
       function CompilaC(){
        $('#respuesta1').html("-");
         Compila2();
        }
    function Compila2(e){
      var NombreA = $('#calsep').val();
      var programa = $('#Programa').val();
      var carpeta = $('#Compila').val();
        // Obtener valores de los campos de texto
       var parametros = {Nombre :NombreA};
        // Realizar la petición
      var post = $.post(
                              "1/compilar.php",    // Script que se ejecuta en el servidor
                            parametros,
                            siRespuesta2,    // Función que se ejecuta cuando el servidor responde
                            'html'          // Tipo de respuesta del servidor
                           );

        /* Registrar evento de la petición (hay mas)
           (no es obligatorio implementarlo, pero es muy recomendable para detectar errores) */

      post.error(siError);         // Si ocurrió un error al ejecutar la petición se ejecuta "siError"
    }



    function Archivos(e) { //abrimos los archivos java que se encuentran en la carpeta
        var carpeta = $('#Compila').val();
        var parametros = {carpeta: carpeta};
        var post = $.post(
            "Archivos.php"
            , parametros
            , siRespuesta1
            , 'html'
        );
        post.error(siError);
    }



    function Guardar1(e) {
        Guardar();
        Archivos();

    }




    setTimeout('Archivos()', 1 * 1000); //abre los archivos del usuario

    $('#Programar')
        .click(programar); // Registrar evento al boton "Calcular" con la funcion "Programa"
    $('#Guardar')
        .click(Guardar1); // Registrar evento al boton "Calcular" con la funcion "Guardar"
    $('#Compila')
        .click(Compila); // Registrar evento al boton "Calcular" con la funcion "Compilar"
    $('#subir')
        .click(SubirArchivo); // Registrar evento al boton "Calcular" con la funcion "subir"

});

function siRespuesta1(r) {
    $('#Archivos').html(r); // Mostrar la respuesta del servidor en el div con el id "respuesta"
}

function Abrir(archivo) { //abrimos el archivo que quiere editar el usuario
    var Archi = archivo;
    subCadena = Archi.split(".", 2);
    siRespuesta3(subCadena[0]);

    var parametros = {
        carpeta: Archi
    };


    var post = $.post(
        "Abrir.php"
        , parametros
        , siRespuesta4
        , 'html' );



    post.error(siError1);
}

function siError1(e) {
    alert('Ocurrió un error al realizar la petición: ' + e.statusText);
}


function siRespuesta3(r) {
         document.getElementById("Nombre")
        .value = r;
         document.getElementById("calsep")
        .value = r;// Mostrar la respuesta del servidor en el div con el id "respuesta"
}

function siRespuesta4(r) {
    document.getElementById("Programa")
        .value = r;


}

function Archivos(e) { //abre los archivos del usuario
    var carpeta = $('#Compila').val();
    var parametros = {carpeta: carpeta};
    var post = $.post("Archivos.php", parametros
        , siRespuesta1
        , 'html'
    );


    post.error(siError1);
}


function SubirArchivo() { //subir los archivos java
    var inputFileImage = document.getElementById('ARCHIVO');

    var file = inputFileImage.files[0];

    var data = new FormData();

    data.append('archivo', file);

    var url = "SubirArchivo.php";

    $.ajax({

        url: url,

        type: 'POST',

        contentType: false,

        data: data,

        processData: false,

        cache: false
        , success: function (data) {
            limpiar();
            $('#respuesta')
                .html(data);
        }
    });

}

function limpiar() { //limpia el formulario
    document.formulario.reset();
    return false;
}
