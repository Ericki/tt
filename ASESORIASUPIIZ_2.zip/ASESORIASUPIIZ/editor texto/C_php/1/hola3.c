#include <stdio.h>

int main()
{
        printf("Hola mundo como etas \n");
        printf("Hola bien bien si ");
for(int x=2;x<100*100;x+=2)
    {
        printf("El contador X vale: %d\n",x);
    }
        return 0;
}