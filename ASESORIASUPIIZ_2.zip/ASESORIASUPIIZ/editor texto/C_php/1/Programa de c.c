//Programa de asesorias Programa de c
// Clase principal iniciadora del programa ejemplo en c
#include <stdio.h>
int main(int argc, const char * argv[]){
//CICLOS FOR EN C
   printf("El contador X vale: %d\n",x);

 return 0;
}
}//fin de main