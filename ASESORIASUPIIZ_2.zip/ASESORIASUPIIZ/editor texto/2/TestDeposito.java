// Clase principal iniciadora del programa ejemplo aprenderaprogramar.com

public class TestDeposito {

    public static void main (String [ ] args) {

 

        //Aquí las instrucciones de inicio y control del programa

 

        System.out.println ("Empezamos la ejecución del programa si jala");

 

    } //Cierre del main

} //Cierre de la clase