// Clase principal iniciadora del programa ejemplo aprenderaprogramar.com

public class nuevo {

    public static void main (String [ ] args) {

 

        //Aquí las instrucciones de inicio y control del programa

 

        System.out.println ("Empezamos la ejecución del programa");

 

    } //Cierre del main

} //Cierre de la clase