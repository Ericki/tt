<?php
$var1 = $_POST['Nombre'];


foreach(glob( "*") as $archivos_carpeta)
	{
		$trozos = explode(".", $archivos_carpeta);
		 $extension = end($trozos);
	if ($extension=="class") {
	 unlink($archivos_carpeta);

	}

	}

system('javac '.$var1.'.java > resultado.txt 2> Errores.txt');
$file = fopen("Errores.txt", "r");
while(!feof($file)) {
echo fgets($file). "";
}
fclose($file);

$file = fopen("resultado.txt", "r");
while(!feof($file)) {
echo fgets($file). "";
}
fclose($file);

system('java '.$var1.'> resultado.txt 2> Errores.txt');

$file = fopen("Errores.txt", "r");
while(!feof($file)) {
echo fgets($file). "";
}
fclose($file);

$file = fopen("resultado.txt", "r");
while(!feof($file)) {
echo fgets($file). "";
}
fclose($file);
?>
