function Abrir(archivo) { //abrimos el archivo que quiere editar el usuario
  alert(archivo);
    var Archi = archivo;
    subCadena = Archi.split(".", 2);
    siRespuesta3(subCadena[0]);

    var parametros = {
        carpeta: Archi
    };


    var post = $.post(
        "Abrir.php"
        , parametros
        , siRespuesta4
        , 'html' );

    post.error(siError1);
}
function siRespuesta3(r) {
    $('#Nombre').html(r); // Mostrar la respuesta del servidor en el div con el id "respuesta"
    $('#calsep').html(r); // Mostrar los archivos
}

function siRespuesta4(r) {
    $('.Programa').html(r);
}
function siRespuesta1(r) {
    $('#Archivos').html(r); // Mostrar los archivos

}
function siError1(e) {
    alert('Ocurrió un error al realizar la petición: ' + e.statusText);
}
