var myAppModule = angular.module('MyApp', ['ui.ace','firebase']);
myAppModule.directive('fileSelect', ['$window', function ($window) {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, el, attr, ctrl) {
            var fileReader = new $window.FileReader();

            fileReader.onload = function () {
                ctrl.$setViewValue(fileReader.result);

                if ('fileLoaded' in attr) {
                    scope.$eval(attr['fileLoaded']);
                }
            };

            fileReader.onprogress = function (event) {
                if ('fileProgress' in attr) {
                    scope.$eval(attr['fileProgress'],
                    {'$total': event.total, '$loaded': event.loaded});
                }
            };

            fileReader.onerror = function () {
                if ('fileError' in attr) {
                    scope.$eval(attr['fileError'],
                    {'$error': fileReader.error});
                }
            };

            var fileType = attr['fileSelect'];

            el.bind('change', function (e) {
                var fileName = e.target.files[0];

                if (fileType === '' || fileType === 'text') {
                    fileReader.readAsText(fileName);
                } else if (fileType === 'data') {
                    fileReader.readAsDataURL(fileName);
                }
            });
        }
    };
}]);

myAppModule.controller('AceCtrl', function($scope,$firebaseArray) {

      var ref = new Firebase("https://fireblogger-11541.firebaseio.com");

      // create a synchronized array
      $scope.messages = $firebaseArray(ref);
      // add new items to the array
      // the message is automatically added to our Firebase database!
      $scope.addMessage = function() {
        $scope.messages.$add({
          text: $scope.newMessageText
        });
      };

	// The modes
  $scope.modes = ['C_Cpp', 'Javascript', 'Java'];
  $scope.mode = $scope.modes[2];


  // The ui-ace option
  $scope.aceOption = {
    mode: $scope.mode.toLowerCase(),
    onLoad: function (_ace) {
      // HACK to have the ace instance in the scope...
      $scope.modeChanged = function () {
        _ace.getSession().setMode("ace/mode/" + $scope.mode.toLowerCase());
      };

    }
  };



//////////////////////////////////////////////////////////////////////////////////////////
angular.element(document).ready(
  function () {
    function siRespuesta(r) {
        $('#respuesta').html(r); // Mostrar la respuesta del servidor en el div con el id "respuesta"
    }
    function siRespuesta2(r) {
        $('#respuesta').html(r); // Mostrar la respuesta del servidor en el div con el id "respuesta"
    }

    function siRespuesta1(r) {
        $('#Archivos').html(r); // Mostrar los archivos
    }
    function siError(e) {
        alert('Ocurrió un error al realizar la petición: ' + e.statusText);
    }

    $scope.programar = function () { // creamos la carpeta en donde se guardara las clases
        var programa = $('#Programar').val();
        var parametros = {variable1: programa};
        var post = $.post(
            "programar.php"
            , parametros
            , siRespuesta
            , 'html'
        );
        post.error(siError);
    }


        function Guardar(e) { //guardamos y editamos los las clases del proyecto del usuario
            $scope.texx = e;
            alert($scope.texx)
            var NombreA = $('#Nombre').val();
            var programa = $scope.texx;
            var carpeta = $('#Guardar').val();

            var parametros = {
                Nombre: NombreA
                , programa: programa
                , carpeta: carpeta
            };


            var post = $.post(
                "guardar.php"
                , parametros
                , siRespuesta
                , 'html'
            );

            post.error(siError);
        }
        $scope.Compila = function (cod) { // compilamos el codigo
            $scope.cod = cod;
            alert($scope.cod = cod);
            var NombreA = $('#calsep').val();
            var programa = $scope.cod;
            alert(programa);
            var carpeta = $('#Compila').val();
            var parametros = {
                Nombre: NombreA
                , programa: programa
                , carpeta: carpeta
            };
            var post = $.post(
                "2/compilar.php"
                , parametros
                , siRespuesta
                , 'html'
            );



            post.error(siError);
        }

        $scope.Archivos = function () { //abrimos los archivos java que se encuentran en la carpeta
            var carpeta = $('#Compila').val();
            var parametros = {carpeta: carpeta};
            var post = $.post(
                "Archivos.php"
                , parametros
                , siRespuesta1
                , 'html'
            );

            post.error(siError);
        }

        Archivos();
        $scope.Guardar1 = function (tex) {
            Guardar(tex);
            Archivos();

        }




//        setTimeout('Archivos()', 1 * 1000); //abre los archivos del usuario

//         $('#Programar').click(programar); // Registrar evento al boton "Calcular" con la funcion "Programa"
//        $('#Guardar').click(Guardar1); // Registrar evento al boton "Calcular" con la funcion "Guardar"
//        $('#Compila').click(Compila); // Registrar evento al boton "Calcular" con la funcion "Compilar"
//        $('#subir').click(SubirArchivo); // Registrar evento al boton "Calcular" con la funcion "subir"


function siRespuesta1(r) {
    $('#Archivos').html(r); // Mostrar la respuesta del servidor en el div con el id "respuesta"
}

function Abrir(archivo) { //abrimos el archivo que quiere editar el usuario
  alert()
    var Archi = archivo;
    subCadena = Archi.split(".", 2);
    siRespuesta3(subCadena[0]);

    var parametros = {
        carpeta: Archi
    };


    var post = $.post(
        "Abrir.php"
        , parametros
        , siRespuesta4
        , 'html' );



    post.error(siError1);
}

function siError1(e) {
    alert('Ocurrió un error al realizar la petición: ' + e.statusText);
}


function siRespuesta3(r) {
    $('#Nombre').html(r); // Mostrar la respuesta del servidor en el div con el id "respuesta"
}

function siRespuesta4(r) {
    document.getElementById("Programa")
        .value = r;


}

function Archivos(e) { //abre los archivos del usuario
    var carpeta = $('#Compila').val();
    var parametros = {

        carpeta: carpeta
    };


    var post = $.post(
        "Archivos.php"
        , parametros
        , siRespuesta1
        , 'html'
    );


    post.error(siError1);
}

  $scope.SubirArchivo = function() { //subir los archivos java
    var inputFileImage = document.getElementById('ARCHIVO');
    var file = inputFileImage.files[0];
    var data = new FormData();
    data.append('archivo', file);
    var url = "SubirArchivo.php";
    $.ajax({
        url: url,
        type: 'POST',
        contentType: false,
        data: data,
        processData: false,
        cache: false
        , success: function (data) {
            limpiar();
            $('#respuesta')
                .html(data);
        }
    });

}

function limpiar() { //limpia el formulario
    document.formulario.reset();
    return false;
}



  }
);









///////////////////////////////////////////////////////////////////////////////////////////

//compilador java

var elementos;
var descripciones;
var celementos;

    $scope.fAgrega = function( tex1) {
      $scope.tex = tex1;
        alert($scope.tex);
      var contador = 0;
        var elemento = [];
        var descripcion = [];
        var texto = $scope.tex;
        var tex2 = "";
        var tex3 = "";
        var palabrasR = "";
        var palabra = "";
        var simbolo = "";
        var simbolos = "";
        var salto = "";
        var encontrosinvolo = "";
        var identificador = /([A-Z]|\$|\_|[a-z])+([A-Z]|\$|\-|[a-z]|[0-9])*/g;
        var dijito = /([0-9])*((\.)([0-9])*)?/g;

        for (var i = texto.length - 1; i >= 0; i--) {
            // texto = texto.replace("\n", " ");
            switch (texto[i]) {
                case "\n":
                    salto = "\n";
                    break;
                case "(":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case ")":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case "{":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case "}":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case "[":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case "]":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case "\"":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case "\'":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case ";":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case "=":
                    simbolo = texto[i];
                    var s2 = i - 1; // valor de i -1
                    if (s2 >= 0) {
                        var simbolo2 = texto[i] + texto[s2];
                        switch (simbolo2) {
                            case "==":
                                simbolo = simbolo2;
                                simbolo2 = "";
                                i--;
                                break;
                            case "=!":
                                simbolo = "!=";
                                simbolo2 = "";
                                i--;
                                break;
                            case "=>":
                                simbolo = ">=";
                                simbolo2 = "";
                                i--;
                                break;
                            case "=<":
                                simbolo = "<=";
                                simbolo2 = "";
                                i--;
                                break;
                            case "=+":
                                simbolo = "+=";
                                simbolo2 = "";
                                i--;
                                break;
                            case "=-":
                                simbolo = "-=";
                                simbolo2 = "";
                                i--;
                                break;
                            case "=*":
                                simbolo = "*=";
                                simbolo2 = "";
                                i--;
                                break;
                            case "=/":
                                simbolo = "/=";
                                simbolo2 = "";
                                i--;
                                break;
                            case "=%":
                                simbolo = "%=";
                                simbolo2 = "";
                                i--;
                                break;
                        }
                    }
                    encontrosinvolo = "si";
                    break;
                case ",":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case ":":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case ".":
                    var s2 = i + 1; // valor de i -1
                    if ((s2 <= texto.length - 1)) {
                        var simbolo2 = texto[s2];
                        if ((isNaN(simbolo2))) {
                            encontrosinvolo = "si";
                            simbolo = texto[i];
                            simbolo2 = "";
                        } else {
                            palabra = texto[i] + palabra;
                        }
                    } else {
                        encontrosinvolo = "si";
                        simbolo = texto[i];
                        simbolo2 = "";
                    }
                    break;
                case "+":
                    simbolo = texto[i];
                    var s2 = i - 1; // valor de i -1
                    if (s2 >= 0) {
                        var simbolo2 = texto[i] + texto[s2];
                        if (simbolo2 == "++") {
                            simbolo = simbolo2;
                            simbolo2 = "";
                            i--;
                        }
                    }
                    encontrosinvolo = "si";
                    break;
                case "-":
                    simbolo = texto[i];
                    var s2 = i - 1; // valor de i -1
                    if (s2 >= 0) {
                        var simbolo2 = texto[i] + texto[s2];
                        if (simbolo2 == "--") {
                            simbolo = simbolo2;
                            simbolo2 = "";
                            i--;
                        }
                    }
                    encontrosinvolo = "si";
                    break;
                case "*":
                    simbolo = texto[i];
                    var s2 = i - 1; // valor de i -1
                    if (s2 >= 0) {
                        var simbolo2 = texto[i] + texto[s2];
                        if (simbolo2 == "*/") {
                            simbolo = "/*";
                            simbolo2 = "";
                            i--;
                        }
                    }
                    encontrosinvolo = "si";
                    break;
                case "/":
                    simbolo = texto[i];
                    var s2 = i - 1; // valor de i -1
                    if (s2 >= 0) {
                        var simbolo2 = texto[i] + texto[s2];
                        if (simbolo2 == "/*") {
                            simbolo = "*/";
                            simbolo2 = "";
                            i--;
                        }
                        if (simbolo2 == "//") {
                            simbolo = "//";
                            simbolo2 = "";
                            i--;
                        }
                    }
                    encontrosinvolo = "si";
                    break;
                case "%":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case ">":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case "<":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case "!":
                    simbolo = texto[i];
                    encontrosinvolo = "si";
                    break;
                case "&":
                    var s2 = i - 1; // valor de i -1
                    if (s2 >= 0) {
                        var simbolo2 = texto[i] + texto[s2];
                        if (simbolo2 == "&&") {
                            simbolo = simbolo2;
                            simbolo2 = "";
                            i--;
                        } else {
                            palabra = texto[i] + palabra;
                        }
                    }
                    encontrosinvolo = "si";
                    break;
                case "|":
                    var s2 = i - 1; // valor de i -1
                    if (s2 >= 0) {
                        var simbolo2 = texto[i] + texto[s2];
                        if (simbolo2 == "||") {
                            simbolo = simbolo2;
                            simbolo2 = "";
                            i--;
                        } else {
                            palabra = texto[i] + palabra;
                        }
                    }
                    encontrosinvolo = "si";
                    break;
                default:
                    if (texto[i] != " ") {
                        palabra = texto[i] + palabra;

                    }
                    break;
            }
            if (texto[i] == " " || i == 0 || encontrosinvolo == "si" || salto == "\n") {
                if ((palabra == "abstract") || (palabra == "rest") || (palabra == "inner") || (palabra == "future") || (palabra == "byvalue") || (palabra == "cast") || (palabra == "generic") || (palabra == "operator") || (palabra == "outer") || (palabra == "true") || (palabra == "null") || (palabra == "false") || (palabra == "var") || (palabra == "assert") || (palabra == "boolean") || (palabra == "break") || (palabra == "byte") || (palabra == "case") || (palabra == "catch") || (palabra == "char") || (palabra == "class") || (palabra == "const") || (palabra == "continue") || (palabra == "default") || (palabra == "do") || (palabra == "double") || (palabra == "else") || (palabra == "enum") || (palabra == "extends") || (palabra == "final") || (palabra == "finally") || (palabra == "float") || (palabra == "for") || (palabra == "goto") || (palabra == "if") || (palabra == "implements") || (palabra == "import") || (palabra == "instanceof") || (palabra == "int") || (palabra == "interface") || (palabra == "long") || (palabra == "native") || (palabra == "new") || (palabra == "package") || (palabra == "private") || (palabra == "protected") || (palabra == "public") || (palabra == "return") || (palabra == "short") || (palabra == "static") || (palabra == "strictfp") || (palabra == "super") || (palabra == "switch") || (palabra == "synchronized") || (palabra == "this") || (palabra == "throw") || (palabra == "throws") || (palabra == "transient") || (palabra == "try") || (palabra == "void") || (palabra == "volatile") || (palabra == "while")) {
                    elemento.push(palabra); //  cambiar por json
                    descripcion.push("PalabraR");
                    palabrasR = palabra + "\n" + palabrasR;
                    palabra = "";
                } else {
                    if (palabra != "") {
                        if (identificador.test(palabra)) {
                            elemento.push(palabra); //  cambiar por json
                            descripcion.push("identificador");
                            tex2 = palabra + "-" + tex2;
                            palabra = "";
                        }
                    }
                    if (palabra != "") {
                        elemento.push(palabra); //  cambiar por json
                        descripcion.push("identificador"); // revisar expprecioon regular
                        tex3 = palabra + "-" + tex2;
                        palabra = "";
                    }
                }
                if (simbolo != "") {
                    simbolos = simbolo + "\n" + simbolos;
                    elemento.push(simbolo); //  cambiar por json
                    descripcion.push("simbolo");
                    simbolo = "";
                    encontrosinvolo = "";
                }
            }
            if (salto != "") {
                elemento.push("\n"); //  cambiar por json
                descripcion.push("salto");
                salto = "";
            }
        }
        elementos = elemento;
        descripciones = descripcion;
        celementos = descripcion.length - 1;
        ProgramaP();
    }


    function ProgramaP() {
        BloqueC();
        AuxPaq();
        BloqueC();
        Clase();
    }

    function AuxPaq() {
        quitarsaltos();
        if ((elementos[celementos] != "abstract") && (elementos[celementos] != "final") && (elementos[celementos] != "private") && (elementos[celementos] != "default") && (elementos[celementos] != "protecte") && (elementos[celementos] != "public") && (elementos[celementos] != "interface") && (elementos[celementos] != "class") && (elementos[celementos] != "/*") && (elementos[celementos] != "//")) {
            Paquete();
            if (celementos >= 0) {
                AuxPaq();
            }
        }
    }

    function BloqueC() {
        quitarsaltos();
        if ((elementos[celementos] != "abstract") && (elementos[celementos] != "final") && (elementos[celementos] != "class") && (elementos[celementos] != "interface") && (elementos[celementos] != "public") && (elementos[celementos] != "default") && (elementos[celementos] != "private")) {
            switch (elementos[celementos]) {
                case "//":
                    celementos--;
                    if (celementos >= 0) {
                        Comentario();
                    }
                    if (celementos >= 0) {
                        BloqueC();
                    }
                    break;
                case "/*":
                    celementos--;
                    if (celementos >= 0) {
                        Comentarios();
                    }
                    if (celementos >= 0) {
                        BloqueC();
                    }
                    break;
            }
        }
    }

    function Paquete() {
        Aux1();
        if (celementos >= 0) {
            while (elementos[celementos] != ";") {
                if (celementos >= 0) {
                    celementos--;
                } else {
                    siRespuesta("se espera ; en vez de "+elementos[celementos]);
                    celementos = -1;
                    break;
                }
            }
            celementos--;
        }
    }

    function Aux1() {
        if ((elementos[celementos] == "package") || (elementos[celementos] == "import")) {
            celementos--;
        } else {
             siRespuesta("se espera packege o import  en vez de "+elementos[celementos]);
            celementos = -1;
        }
    }

    function Clase() {
        if (celementos >= 0) {
            Aux2();
        }
        if (celementos >= 0) {
            Aux3();
        }
        if (celementos >= 0) {


        if ((descripciones[celementos] == "identificador")) {
            celementos--;
        } else {
            siRespuesta("se espera un identificador o valor  en vez de "+elementos[celementos]);
            celementos = -1;
        }
         }
        if (celementos >= 0) {
            Aux4();
        }
        quitarsaltos();
        if (celementos >= 0) {
            if ((elementos[celementos] == "{")) {
                celementos--;
            } else {
                siRespuesta("se espera { en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            BLOQUE2();
        }
        if (celementos >= 0) {
            Aux7();
        }
        quitarsaltos();
        if (celementos >= 0) {
            if ((elementos[celementos] == "}")) {
                celementos--;
            } else {
                 siRespuesta("se espera } en vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
    }

    function Aux2() {
        if ((elementos[celementos] != "enum") && (elementos[celementos] != "boolean") && (elementos[celementos] != "double") && (elementos[celementos] != "string") && (elementos[celementos] != "char") && (elementos[celementos] != "float") && (elementos[celementos] != "long") && (elementos[celementos] != "int") && (elementos[celementos] != "array") && (elementos[celementos] != "byte") && (elementos[celementos] != "short") && (elementos[celementos] != "object") && (elementos[celementos] != "interface") && (elementos[celementos] != "class"))
            modificadores();
    }

    function Aux3() {
        if ((elementos[celementos] == "class") || (elementos[celementos] == "interface")) {
            celementos--;
        } else {
            celementos = -1;
             siRespuesta("se espera class o interface en vez de "+elementos[celementos]);
            celementos = -1;
        }
    }

    function Aux4() {
        quitarsaltos();
        if (elementos[celementos] != "{") {
            Aux5();
            if ((descripciones[celementos] == "identificador")) {
                celementos--;
            } else {
              siRespuesta("se espera un identificador o valor  en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
    }

    function Aux5() {
        if ((elementos[celementos] == "extends") || (elementos[celementos] == "interface")) {
            celementos--;
        } else {
            siRespuesta("se espera un extens o implements en vez de "+elementos[celementos]);
            celementos = -1;

        }
    }

    function Aux7() {
        quitarsaltos();
        if (celementos >= 0) {
            if ((elementos[celementos] != "}")) {
                MAIN_();
            }
        }
    }

    function Comentario() {
        while (elementos[celementos] != "\n") {
            var elemet = elementos[celementos];
            if (celementos >= 0) {
                celementos--
            } else break;
        }
        celementos--;
    }

    function Comentarios() {
        while (elementos[celementos] != "*/") {
            var elemet = elementos[celementos];
            if (celementos >= 0) {
                celementos--
            } else {
                 siRespuesta("se espera un */ en vez de "+elementos[celementos]);
            celementos = -1;

                break;
            }
        }
        celementos--;
    }

    function Aux8() {}

    function modificadores() {
        if ((elementos[celementos] == "abstract") || (elementos[celementos] == "final") || (elementos[celementos] == "private") || (elementos[celementos] == "default") || (elementos[celementos] == "protecte") || (elementos[celementos] == "public")) {
            celementos--;
        } else {
            siRespuesta("se espera una siginetes palabras public, protecte, default, private, final o abstract en vez de "+elementos[celementos]);
            celementos = -1;

        }
    }

    function BLOQUE2() {
        quitarsaltos();
        var uso = "";
        if ((celementos - 1) >= 0) {
            uso = elementos[celementos - 1];
        }
        if (celementos >= 0) {
            if (elementos[celementos] != "}" && uso != "static") {
                switch (elementos[celementos]) {
                    case "//":
                        if (celementos >= 0) {
                            BloqueC(); //  //  /*
                        }
                        if (celementos >= 0) {
                            BLOQUE2();
                        }
                        break;
                    case "/*":
                        if (celementos >= 0) {
                            BloqueC();
                        }
                        if (celementos >= 0) {
                            BLOQUE2();
                        }
                        break;
                    case "while":
                        celementos--;
                        if (celementos >= 0) {
                            while_();
                        }
                        if (celementos >= 0) {
                            BLOQUE2();
                        }
                        break;
                    case "try":
                        celementos--;
                        if (celementos >= 0) {
                            Excepciones();
                        }
                        if (celementos >= 0) {
                            BLOQUE2();
                        }
                        break;
                    case "if":
                        celementos--;
                        if (celementos >= 0) {
                            if_else();
                        }
                        if (celementos >= 0) {
                            BLOQUE2();
                        }
                        break;
                    case "for":
                        celementos--;
                        if (celementos >= 0) {
                            for_();
                        }
                        if (celementos >= 0) {
                            BLOQUE2();
                        }
                        break;
                    case "do":
                        celementos--;
                        if (celementos >= 0) {
                            do_while();
                        }
                        if (celementos >= 0) {
                            BLOQUE2();
                        }
                        break;
                    default:
                        if ((elementos[celementos] == "enum") || (elementos[celementos] == "double") || (elementos[celementos] == "boolean") || (elementos[celementos] == "char") || (elementos[celementos] == "String") || (elementos[celementos] == "long") || (elementos[celementos] == "float") || (elementos[celementos] == "array") || (elementos[celementos] == "int") || (elementos[celementos] == "short") || (elementos[celementos] == "object") || (elementos[celementos] == "byte")) {
                            celementos--;
                            if ((celementos - 1) >= 0) {
                                if (elementos[celementos - 1] == "}" || elementos[celementos - 1] == "=" ||elementos[celementos - 1] == ";") {
                                    Variables();
                                    if (celementos >= 0) {
                            BLOQUE2();
                        }
                                } else {
                                    if ((celementos - 2) >= 0) {
                                        if (elementos[celementos - 2] == "(") {
                                            Metodos();
                                            if (celementos >= 0) {
                            BLOQUE2();
                        }
                                        } else {
                                            if (celementos >= 0) {
                                                Arreglos_valores();
                                                if (celementos >= 0) {
                            BLOQUE2();
                        }
                                            }
                                        }
                                    } else {
                                        if (celementos >= 0) {
                                            Arreglos_valores();
                                            if (celementos >= 0) {
                            BLOQUE2();
                        }
                                        }
                                    }
                                }
                            }
                        } else {
                            if ((elementos[celementos] == "abstract") || (elementos[celementos] == "final") || (elementos[celementos] == "private") || (elementos[celementos] == "default") || (elementos[celementos] == "protecte") || (elementos[celementos] == "public")) {
                                celementos--;
                                if ((celementos - 2) >= 0) {
                                    if (elementos[celementos - 2] == "(") {
                                        Metodos();
                                        if (celementos >= 0) {
                            BLOQUE2();
                        }
                                    } else {
                                        Variables();
                                        if (celementos >= 0) {
                            BLOQUE2();
                        }
                                    }
                                } else {
                                    Variables();
                                    if (celementos >= 0) {
                            BLOQUE2();
                        }
                                }
                            } else {
                                if (descripciones[celementos] == "identificador") {
                                    var celementos2 = celementos - 1;
                                    if (celementos2 >= 0) {
                                        switch (elementos[celementos2]) {
                                            case ".":
                                                if (celementos >= 0) {
                                                    Llamar_OBJ(); //  //  /*
                                                }
                                                if (celementos >= 0) {
                                                    BLOQUE2();
                                                }
                                                break;
                                            case "=":
                                                if ((celementos2 - 1) >= 0) {
                                                    if ((elementos[celementos2 - 1] == "new")) {
                                                        if (celementos >= 0) {
                                                            Arreglos(); //  //  /*
                                                        }
                                                        if (celementos >= 0) {
                                                            BLOQUE2();
                                                        }
                                                    } else {
                                                        if ((elementos[celementos2] == "%=") || (elementos[celementos2] == "/=") || (elementos[celementos2] == "*=") || (elementos[celementos2] == "-=") || (elementos[celementos2] == "+=") || (elementos[celementos2] == "=")) {
                                                            if (celementos >= 0) {
                                                                Actualizacion();
                                                            }
                                                            if (celementos >= 0) {
                                                                BLOQUE2();
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    if ((elementos[celementos2] == "%=") || (elementos[celementos2] == "/=") || (elementos[celementos2] == "*=") || (elementos[celementos2] == "-=") || (elementos[celementos2] == "+=") || (elementos[celementos2] == "=")) {
                                                        if (celementos >= 0) {
                                                            Actualizacion();
                                                        }
                                                        if (celementos >= 0) {
                                                            BLOQUE2();
                                                        }
                                                    }
                                                }
                                                break;
                                            default:
                                                if ((elementos[celementos2] == "%=") || (elementos[celementos2] == "/=") || (elementos[celementos2] == "*=") || (elementos[celementos2] == "-=") || (elementos[celementos2] == "+=") || (elementos[celementos2] == "=")) {
                                                    if (celementos >= 0) {
                                                        Actualizacion();
                                                    }
                                                    if (celementos >= 0) {
                                                        BLOQUE2();
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                }
                            }
                        }
                        break;
                }
            }
        }
    }

    function MAIN_() {
        if (celementos >= 0) {
            if ((elementos[celementos] == "public")) {
                celementos--;
            } else {
                siRespuesta("se espera un  public en vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "static")) {
                celementos--;
            } else {
                   siRespuesta("se espera  static en vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "void")) {
                celementos--;
            } else {
                siRespuesta("se espera  void en vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "main")) {
                celementos--;
            } else {
                siRespuesta("se espera  main en vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "(")) {
                celementos--;
            } else {
                siRespuesta("se espera  ( en vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "String")) {
                celementos--;
            } else {
                siRespuesta("se espera  String en vez de "+elementos[celementos]);
            celementos = -1;

            }
        }

        if (celementos >= 0) {
            if ((elementos[celementos] == "[")) {
                celementos--;
            } else {
                  siRespuesta("se espera  [ en vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "]")) {
                celementos--;
            } else {
                siRespuesta("se espera  ] en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((descripciones[celementos] == "identificador")) {
                celementos--;
            } else {
                siRespuesta("se espera un identificador o valor  en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ")")) {
                celementos--;
            } else {
                siRespuesta("se espera  ) en vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "{")) {
                celementos--;
            } else {
                  siRespuesta("se espera  { en vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
        if (celementos >= 0) {
            BLOQUE2();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "}")) {
                celementos--;
            } else {

                siRespuesta("se espera  } en vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
    }

    function Crear_e_Inicializar_objeto() {
        if (celementos >= 0) {
            if (descripciones[celementos] == "identificador") {
                celementos--;
                if (celementos >= 0) {
                    if (descripciones[celementos] == "identificador") {
                        celementos--;
                        if ((elementos[celementos] == "=")) {
                            celementos--;
                            if (celementos >= 0) {
                                if ((elementos[celementos] == "new")) {
                                    celementos--;
                                    if (celementos >= 0) {
                                        if (descripciones[celementos] == "identificador") {
                                            celementos--;
                                            if (celementos >= 0) {
                                                if ((elementos[celementos] == "(")) {
                                                    celementos--;
                                                } else {
                                                    celementos = -1;
                                                   siRespuesta("se espera  ( en vez de "+elementos[celementos]);
            celementos = -1;
                                                }
                                            }
                                            if (celementos >= 0) {
                                                if ((elementos[celementos] == ")")) {
                                                    celementos--;
                                                } else {
                                                     siRespuesta("se espera  ) en vez de "+elementos[celementos]);
            celementos = -1;
                                                }
                                            }
                                            if (celementos >= 0) {
                                                if ((elementos[celementos] == ";")) {
                                                    celementos--;
                                                } else {
                                                    siRespuesta("se espera  ; en vez de "+elementos[celementos]);
            celementos = -1;

                                                }
                                            }
                                        } else {
                                            siRespuesta("se espera  identificador en vez de "+elementos[celementos]);
            celementos = -1;
                                        }
                                    }
                                } else {
                                     siRespuesta("se espera  new en vez de "+elementos[celementos]);
            celementos = -1;

                                }
                            }
                        } else {
                            if ((elementos[celementos] == ";")) {
                                celementos--;
                            } else {
                                 siRespuesta("se espera  = o un identificador o ; en vez de "+elementos[celementos]);
            celementos = -1;

                            }
                        }
                    } else {
                        if ((elementos[celementos] == "=")) {
                            celementos--;
                            if (celementos >= 0) {
                                if ((elementos[celementos] == "new")) {
                                    celementos--;
                                    if (celementos >= 0) {
                                        if (descripciones[celementos] == "identificador") {
                                            celementos--;
                                            if (celementos >= 0) {
                                                if ((elementos[celementos] == "(")) {
                                                    celementos--;
                                                } else {
                                                    siRespuesta("se espera  ( en vez de "+elementos[celementos]);
            celementos = -1;
                                                }
                                            }
                                            if (celementos >= 0) {
                                                if ((elementos[celementos] == ")")) {
                                                    celementos--;
                                                } else {
                                                    celementos = -1;
                                                     siRespuesta("se espera  ) en vez de "+elementos[celementos]);
            celementos = -1;
                                                }
                                            }
                                            if (celementos >= 0) {
                                                if ((elementos[celementos] == ";")) {
                                                    celementos--;
                                                } else {
                                                    siRespuesta("se espera  ; en vez de "+elementos[celementos]);
            celementos = -1;
                                                }
                                            }
                                        } else {
                                             siRespuesta("se espera  identificador en vez de "+elementos[celementos]);
            celementos = -1;

                                        }
                                    }
                                } else {
                                    celementos = -1;
                                            siRespuesta("se espera new en vez de "+elementos[celementos]);
            celementos = -1;
                                }
                            }
                        } else {
                            siRespuesta("se espera  = o un identificador en vez de "+elementos[celementos]);
            celementos = -1;

                        }
                    }
                }
            } else {
                siRespuesta("se espera  = o un identificador en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
    }

    function Aux9() {}

    function Aux10() {}

    function Aux11() {
        if (elementos[celementos] != ";") {
            if (celementos >= 0) {
                if ((elementos[celementos] == "{")) {
                    celementos--;
                } else {
                    siRespuesta("se espera  { en vez de "+elementos[celementos]);
            celementos = -1;
                }
            }
            if (celementos >= 0) {
                Metodos()
            }
            if (celementos >= 0) {
                if ((elementos[celementos] == "}")) {
                    celementos--;
                } else {
                    siRespuesta("se espera  } en vez de "+elementos[celementos]);
            celementos = -1;
                }
            }
        }
    }

    function Arreglos_valores() {
        if (celementos >= 0) {
            if ((descripciones[celementos] == "identificador")) {
                celementos--;
            } else {
              siRespuesta("se espera un identificador o valor  en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "[")) {
                celementos--;
            } else {
               siRespuesta("se espera  [ en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "]")) {
                celementos--;
            } else {
                siRespuesta("se espera  ] en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "=")) {
                celementos--;
            } else {
                         siRespuesta("se espera  = vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "{")) {
                celementos--;
            } else {
                siRespuesta("se espera  { en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            Aux12();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "}")) {
                celementos--;
            } else {
                siRespuesta("se espera  } en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ";")) {
                celementos--;
            } else {
                celementos = -1;
                 siRespuesta("se espera  ; en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
    }

    function Aux12() {
        if (celementos >= 0) {
            if ((descripciones[celementos] == "identificador")) {
                celementos--;
            } else {
                siRespuesta("se espera un identificador o valor  en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            Aux13();
        }
    }

    function Aux13() {
        if ((elementos[celementos] != "}")) {
            if (celementos >= 0) {
                if ((elementos[celementos] == ",")) {
                    celementos--;
                } else {
                     siRespuesta("se espera  , vez de "+elementos[celementos]);
            celementos = -1;
                }
            }
            if (celementos >= 0) {
                Aux12();
            }
        }
    }

    function Variables() {


        if (celementos >= 0) {
            if ((descripciones[celementos] == "identificador")) {
                celementos--;
            } else {
                 siRespuesta("se espera  identificador vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
        if (celementos >= 0) {
            Aux14();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ";")) {
                celementos--;
            } else {
                celementos = -1;
                siRespuesta("se espera  ; en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
    }

    function Aux14() {
        if ((elementos[celementos] != ";")) {
            switch (elementos[celementos]) {
                case "{":
                    if (celementos >= 0) {
                        Aux15();
                    }
                    if (celementos >= 0) {
                        if ((elementos[celementos] == "}")) {
                            celementos--;
                        } else {
                            siRespuesta("se espera  } en vez de "+elementos[celementos]);
            celementos = -1;
                        }
                    }
                    break;
                case "=":
                celementos--;
                    if (celementos >= 0) {
                        Aux17();
                    }
                    break;
            }
        }
    }

    function Aux15() {
        if (celementos >= 0) {
            if ((descripciones[celementos] == "identificador")) {
                celementos--;
            } else {
                 siRespuesta("se espera  identificador vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
        if (celementos >= 0) {
            Aux16();
        }
    }

    function Aux16() {
        if ((elementos[celementos] != "}")) {
            if (celementos >= 0) {
                if ((elementos[celementos] == ",")) {
                    celementos--;
                } else {
                    siRespuesta("se espera  , vez de "+elementos[celementos]);
            celementos = -1;
                }
            }
            if (celementos >= 0) {
                Aux15();
            }
        }
    }

    function Aux17() {
        if (celementos >= 0) {
            if ((descripciones[celementos] == "identificador")|| (elementos[celementos] == "\"")) {
                if (elementos[celementos] == "\"") {
                    celementos--;
     while (elementos[celementos] != "\"") {
                if (celementos >= 0) {
                    celementos--;
                } else {

                   siRespuesta("se espera  \" vez de "+elementos[celementos]);
            celementos = -1;
                    break;
                }
            }
    celementos--;
                }else
                celementos--;
            } else {
                siRespuesta("se espera  identificador vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            Aux18();
        }
    }

    function Aux18() {
        if ((elementos[celementos] != ";")) {
            if (celementos >= 0) {
                Operadores_aritmeticos();
            }
            if (celementos >= 0) {
                Aux17();
            }
        }
    }

    function Excepciones() {
        if ((elementos[celementos] == "{")) {
            celementos--;
        } else {
            siRespuesta("se espera  { en vez de "+elementos[celementos]);
            celementos = -1;
        }
        if (celementos >= 0) {
            BLOQUE2();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "}")) {
                celementos--;
            } else {
                siRespuesta("se espera  } en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            Aux19();
        }
        if (celementos >= 0) {
            Aux20();
        }
    }

    function Aux19() {
        if (celementos >= 0) {
            if ((elementos[celementos] == "catch")) {
                celementos--;
            } else {
                siRespuesta("se espera  catch vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "(")) {
                celementos--;
            } else {
               siRespuesta("se espera  ( vez de "+elementos[celementos]);
            celementos = -1;
            }
            if (celementos >= 0) {}
            if (descripciones[celementos] == "identificador") {
                celementos--;
            } else {
                siRespuesta("se espera  exepcion vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
        if (celementos >= 0) {
            if (descripciones[celementos] == "identificador") {
                celementos--;
            } else {
                siRespuesta("se espera nombre de la exepcion vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ")")) {
                celementos--;
            } else {
                siRespuesta("se espera  ) vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "{")) {
                celementos--;
            } else {
                siRespuesta("se espera  ( vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            BLOQUE2();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "}")) {
                celementos--;
            } else {
                siRespuesta("se espera  } vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
    }

    function Aux20() {
        quitarsaltos();
        if ((descripciones[celementos] != "identificador") && (elementos[celementos] != "}") && (elementos[celementos] != "/*") && (elementos[celementos] != "//") && (elementos[celementos] != "do") && (elementos[celementos] != "if") && (elementos[celementos] != "while") && (elementos[celementos] != "try") && (elementos[celementos] != "interface") && (elementos[celementos] != "class") && (elementos[celementos] != "abstract") && (elementos[celementos] != "final") && (elementos[celementos] != "private") && (elementos[celementos] != "default") && (elementos[celementos] != "protecte") && (elementos[celementos] != "public") && (elementos[celementos] != "enum") && (elementos[celementos] != "double") && (elementos[celementos] != "boolean") && (elementos[celementos] != "char") && (elementos[celementos] != "String") && (elementos[celementos] != "long") && (elementos[celementos] != "float") && (elementos[celementos] != "array") && (elementos[celementos] != "int") && (elementos[celementos] != "short") && (elementos[celementos] != "byte") && (elementos[celementos] != "object")) {
            if (elementos[celementos] == "finally") {
                celementos--;
                quitarsaltos();
                if (celementos >= 0) {
                    if ((elementos[celementos] == "{")) {
                        celementos--;
                    } else {
                        siRespuesta("se espera  { vez de "+elementos[celementos]);
            celementos = -1;
                    }
                }
                if (celementos >= 0) {
                    BLOQUE2();
                }
                if (celementos >= 0) {
                    if ((elementos[celementos] == "}")) {
                        celementos--;
                        quitarsaltos();
                    } else {
                        siRespuesta("se espera  } vez de "+elementos[celementos]);
            celementos = -1;
                    }
                }
            } else {
                if (celementos >= 0) {
                    Aux19();
                }
                if (celementos >= 0) {
                    Aux20();
                }
            }
        }
    }

    function while_() {
        if (celementos >= 0) {
            if ((elementos[celementos] == "(")) {
                celementos--;
            } else {
                siRespuesta("se espera  ( en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            expresion_Boolean();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ")")) {
                celementos--;
            } else {
                celementos = -1;
                 siRespuesta("se espera  ) en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "{")) {
                celementos--;
            } else {
                siRespuesta("se espera  { en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            BLOQUE2();
        }
        quitarsaltos();
        if (celementos >= 0) {
            if ((elementos[celementos] == "}")) {
                celementos--;
            } else {
                siRespuesta("se espera  } en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
    }

    function if_else() {
        if (celementos >= 0) {
            if ((elementos[celementos] == "(")) {
                celementos--;
            } else {
                celementos = -1;
               siRespuesta("se espera  ( en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            expresion_Boolean();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ")")) {
                celementos--;
            } else {
                celementos = -1;
                  siRespuesta("se espera  ) en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "{")) {
                celementos--;
            } else {
                siRespuesta("se espera  { en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            BLOQUE2();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "}")) {
                celementos--;
            } else {
                siRespuesta("se espera  } en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            Aux21();
        }
    }

    function Aux21() {
        quitarsaltos();
        if (celementos >= 0) {
            if ((elementos[celementos] == "else")) {
                celementos--;
            } else {
                siRespuesta("se espera  else vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "if")) {
                celementos--;
                if (celementos >= 0) {
                    if ((elementos[celementos] == "(")) {
                        celementos--;
                    } else {
                       siRespuesta("se espera  ( en vez de "+elementos[celementos]);
            celementos = -1;
                    }
                }
                if (celementos >= 0) {
                    expresion_Boolean();
                }
                if (celementos >= 0) {
                    if ((elementos[celementos] == ")")) {
                        celementos--;
                    } else {
                        celementos = -1;
                          siRespuesta("se espera  ) en vez de "+elementos[celementos]);
            celementos = -1;
                    }
                }
                quitarsaltos();
                if (celementos >= 0) {
                    if ((elementos[celementos] == "{")) {
                        celementos--;
                    } else {
                       siRespuesta("se espera  { en vez de "+elementos[celementos]);
            celementos = -1;
                    }
                }
                if (celementos >= 0) {
                    BLOQUE2();
                }
                quitarsaltos();
                if (celementos >= 0) {
                    if ((elementos[celementos] == "}")) {
                        celementos--;
                    } else {
                       siRespuesta("se espera  } en vez de "+elementos[celementos]);
            celementos = -1;
                    }
                }
                if (celementos >= 0) {
                    Aux21();
                }
            } else {
                if (celementos >= 0) {
                    if ((elementos[celementos] == "{")) {
                        celementos--;
                    } else {
                       siRespuesta("se espera  { en vez de "+elementos[celementos]);
            celementos = -1;
                    }
                }
                if (celementos >= 0) {
                    BLOQUE2();
                }
                if (celementos >= 0) {
                    if ((elementos[celementos] == "}")) {
                        celementos--;
                    } else {
                       siRespuesta("se espera  } en vez de "+elementos[celementos]);
            celementos = -1;
                    }
                }
            }
        }
    }

    function Actualizacion() {
        if (celementos >= 0) {
            if ((descripciones[celementos] == "identificador")) {
                celementos--;
            } else {
                celementos = -1;
             siRespuesta("se espera un identificador  en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] != "--") && (elementos[celementos] != "++")) {
                Operadores_de_asignacion();
                if (celementos >= 0) {
                    Aux22();
                }
                if (celementos >= 0) {
                    Aux23();
                }
            } else {
                celementos--;
            }
        }
        if (celementos >= 0) {
            if (elementos[celementos] != ")") {
                if ((elementos[celementos] == ";")) {
                    celementos--;
                } else {
                     siRespuesta("se espera  ; en vez de "+elementos[celementos]);
            celementos = -1;
                }
            }
        }
    }

    function Aux22() {
        if (celementos >= 0) {
            if ((elementos[celementos] == "-") || (elementos[celementos] == "+")) {
                celementos--;
            }
        }
        if (celementos >= 0) {
            if ((descripciones[celementos] == "identificador")) {
                celementos--;
            } else {
                siRespuesta("se espera un identificador o valor  en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
    }

    function Aux23() {
        if ((elementos[celementos] != ";") && (elementos[celementos] != ")")) {
            if (celementos >= 0) {
                Operadores_aritmeticos();
            }
            if (celementos >= 0) {
                Aux22();
            }
            if (celementos >= 0) {
                Aux23();
            }
        }
    }

    function for_() {
        if (celementos >= 0) {
            if ((elementos[celementos] == "(")) {
                celementos--;
            } else {
                celementos = -1;
                siRespuesta("se espera  ( en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            Aux24();
        }
        if (celementos >= 0) {
            expresion_Boolean();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ";")) {
                celementos--;
            } else {
                siRespuesta("se espera  ; en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            Actualizacion();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ")")) {
                celementos--;
            } else {
                celementos = -1;
                 siRespuesta("se espera  ) en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        quitarsaltos();
        if (celementos >= 0) {
            if ((elementos[celementos] == "{")) {
                celementos--;
            } else {
               siRespuesta("se espera  { en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            BLOQUE2();
        }
        quitarsaltos();
        if (celementos >= 0) {
            if ((elementos[celementos] == "}")) {
                celementos--;
            } else {
               siRespuesta("se espera  } en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
    }

    function Aux24() {
        if ((descripciones[celementos] != "identificador") && (elementos[celementos] != "(")) {
            if (celementos >= 0) {
                Aux25();
            }
            if (celementos >= 0) {
                if ((descripciones[celementos] == "identificador")) {
                    celementos--;
                } else {
                    siRespuesta("se espera un identificador o valor  en vez de "+elementos[celementos]);
            celementos = -1;
                }
            }
            if (celementos >= 0) {
                if ((elementos[celementos] == "=")) {
                    celementos--;
                } else {
                   siRespuesta("se espera = vez de "+elementos[celementos]);
            celementos = -1;
                }
            }
            if (celementos >= 0) {
                Aux22();
            }
            if (celementos >= 0) {
                if ((elementos[celementos] == ";")) {
                    celementos--;
                } else {
                    siRespuesta("se espera  ; en vez de "+elementos[celementos]);
            celementos = -1;
                }
            }
        }
    }

    function Aux25() {
        if ((descripciones[celementos] != "identificador")) {
            if (celementos >= 0) {
                if ((elementos[celementos] == "int")) {
                    celementos--;
                } else {
                    siRespuesta("se espera  int vez de "+elementos[celementos]);
            celementos = -1;

                }
            }
        }
    }

    function do_while() {
        quitarsaltos();
        if (celementos >= 0) {
            if ((elementos[celementos] == "{")) {
                celementos--;
            } else {
                siRespuesta("se espera  { en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            BLOQUE2();
        }
        quitarsaltos();
        if (celementos >= 0) {
            if ((elementos[celementos] == "}")) {
                celementos--;
            } else {
                siRespuesta("se espera  } en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        quitarsaltos();
        if (celementos >= 0) {
            if ((elementos[celementos] == "while")) {
                celementos--;
            } else {
                siRespuesta("se espera  while vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "(")) {
                celementos--;
            } else {
               siRespuesta("se espera  ( en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            expresion_Boolean();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ")")) {
                celementos--;
            } else {
                  siRespuesta("se espera  ) en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ";")) {
                celementos--;
            } else {
                 siRespuesta("se espera  ; en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
    }

    function Arreglos() {
        if (celementos >= 0) {
            if ((descripciones[celementos] == "identificador")) {
                celementos--;
            } else {
                siRespuesta("se espera un identificador o valor  en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "=")) {
                celementos--;
            } else {
                siRespuesta("se espera  = vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "new")) {
                celementos--;
            } else {
                siRespuesta("se espera  new vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((descripciones[celementos] == "identificador")) {
                celementos--;
            } else {
                siRespuesta("se espera un identificador o valor  en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "[")) {
                celementos--;
            } else {
               siRespuesta("se espera  [ en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            Aux22();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "]")) {
                celementos--;
            } else {
          siRespuesta("se espera  ] en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ";")) {
                celementos--;
            } else {
                 siRespuesta("se espera  ; en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
    }

    function Metodos() {
        quitarsaltos();
        if (celementos >= 0) {
            Aux2();
        }
        if (celementos >= 0) {
            Datos();
        }
        if (celementos >= 0) {
            if ((descripciones[celementos] == "identificador")) {
                celementos--;
            } else {
                siRespuesta("se espera un identificador o valor  en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "(")) {
                celementos--;
            } else {
               siRespuesta("se espera  ( en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            Datos();
        }
        if (celementos >= 0) {
            Aux26();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ")")) {
                celementos--;
            } else {
                 siRespuesta("se espera  ) en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "{")) {
                celementos--;
            } else {
                siRespuesta("se espera  { en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            BLOQUE2();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == "}")) {
                celementos--;
            } else {
               siRespuesta("se espera  } en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
    }

    function Aux26() {
        if ((elementos[celementos] != ")")) {
            if (celementos >= 0) {
                if ((elementos[celementos] == ",")) {
                    celementos--;
                } else {
                   siRespuesta("se espera  , vez de "+elementos[celementos]);
            celementos = -1;
                }
            }
            if (celementos >= 0) {
                Datos();
            }
            if (celementos >= 0) {
                if ((descripciones[celementos] == "identificador")) {
                    celementos--;
                } else {
                    celementos = -1;
                   siRespuesta("se espera un identificador o valor  en vez de "+elementos[celementos]);
            celementos = -1;
                }
            }
            if (celementos >= 0) {
                Aux26();
            }
        }
    }

    function Llamar_OBJ() {
        if (celementos >= 0) {
            if ((descripciones[celementos] == "identificador")) {
                celementos--;
            } else {
               siRespuesta("se espera un identificador o valor  en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ".")) {
                celementos--;
            } else {
               siRespuesta("se espera  . vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            if ((descripciones[celementos] == "identificador")) {
                celementos--;
            } else {
                celementos = -1;
              siRespuesta("se espera un identificador o valor  en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
        if (celementos >= 0) {
            Aux27();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ";")) {
                celementos--;
            } else {
                siRespuesta("se espera  ; en vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
    }

    function Aux27() {
        if ((elementos[celementos] != ";")) {
            if (celementos >= 0) {
                if ((elementos[celementos] == "(")) {
                    celementos--;
                } else {
                    siRespuesta("se espera  ( en vez de "+elementos[celementos]);
            celementos = -1;
                }
            }
            if (celementos >= 0) {
                Aux28();
            }
            if (celementos >= 0) {
                if ((elementos[celementos] == ")")) {
                    celementos--;
                } else {
                     siRespuesta("se espera  ) en vez de "+elementos[celementos]);
            celementos = -1;
                }
            }
        }
    }

    function Aux28() {
        if ((elementos[celementos] != ")")) {
            if (celementos >= 0) {
                if ((elementos[celementos] == "-") || (elementos[celementos] == "+")) {
                    celementos--;
                }
            }
            if (celementos >= 0) {
                if ((descripciones[celementos] == "identificador")) {
                    celementos--;
                } else {
                    celementos = -1;
                   siRespuesta("se espera un identificador o valor  en vez de "+elementos[celementos]);
            celementos = -1;
                }
            }
        }
    }

    function Datos() {
        if ((elementos[celementos] == "enum") || (elementos[celementos] == "double") || (elementos[celementos] == "boolean") || (elementos[celementos] == "char") || (elementos[celementos] == "String") || (elementos[celementos] == "long") || (elementos[celementos] == "float") || (elementos[celementos] == "array") || (elementos[celementos] == "int") || (elementos[celementos] == "short") || (elementos[celementos] == "object") || (elementos[celementos] == "byte")) {
            celementos--;
        } else {
           siRespuesta("se espera  un tipo de dato vez de "+elementos[celementos]);
            celementos = -1;
        }
    }

    function Operadores_aritmeticos() {
        if (celementos >= 0) {
            if ((elementos[celementos] == "--") || (elementos[celementos] == "++") || (elementos[celementos] == "*") || (elementos[celementos] == "%") || (elementos[celementos] == "/") || (elementos[celementos] == "-") || (elementos[celementos] == "+")) {
                celementos--;
            } else {
                siRespuesta("se espera  Operadores Aritmeticos en  vez de "+elementos[celementos]);
            celementos = -1;
            }
        }
    }

    function expresion_Boolean() {
        if ((elementos[celementos] == "(")) {
            celementos--;
            Aux29();
        } else {
            Aux30();
        }
    }

    function Aux29() {
        if (celementos >= 0) {
            Aux30();
        }
        if (celementos >= 0) {
            if ((elementos[celementos] == ")")) {
                celementos--;
            } else {
                  siRespuesta("se espera  ) en vez de "+elementos[celementos]);
            celementos = -1;
            }
            Aux32();
        }
    }

    function Aux30() {
        Aux22();
        Operadores_relacionales();
        Aux22();
        if (celementos >= 0) {
            if (!(elementos[celementos] == ")")) {
                Aux32();
            }
        }
    }

    function Aux32() {
        if (celementos >= 0) {
            if ((descripciones[celementos] != "identificador") && (elementos[celementos] != ")") && (elementos[celementos] != "(") && (elementos[celementos] != ";")) {
                Operadores_logicos();
            }
        }
    }

    function Operadores_relacionales() {
        if (celementos >= 0) {
            if ((elementos[celementos] == "<=") || (elementos[celementos] == ">=") || (elementos[celementos] == "<") || (elementos[celementos] == ">") || (elementos[celementos] == "==") || (elementos[celementos] == "!=")) {
                celementos--;
            } else {
                siRespuesta("se espera  Operadores relacionales en vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
    }

    function Operadores_logicos() {
        if (celementos >= 0) {
            if ((elementos[celementos] == "||") || (elementos[celementos] == "&&") || (elementos[celementos] == "!")) {
                celementos--;
                expresion_Boolean();
            } else {
                siRespuesta("se espera  Operadores logicos en vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
    }

    function Operadores_de_asignacion() {
        if (celementos >= 0) {
            if ((elementos[celementos] == "%=") || (elementos[celementos] == "/=") || (elementos[celementos] == "*=") || (elementos[celementos] == "-=") || (elementos[celementos] == "+=") || (elementos[celementos] == "=")) {
                celementos--;
            } else {
                siRespuesta("se espera  Operadores asignacion en vez de "+elementos[celementos]);
            celementos = -1;

            }
        }
    }

    function quitarsaltos() {
        if (elementos[celementos] == "\n") {
            if (celementos >= 0) {
                celementos--;
                quitarsaltos();
            }
        }
    }
     function siRespuesta(r){
            $('#Sujerencia').html(r);   // Mostrar la respuesta del servidor en el div con el id "respuesta"
        }






///////////////////////compilar/////////////

// Recomiendo leer este archivo de abajo hacia arriba para comprenderlo mejor.




///////////////////////fin compilar//////////



  // Initial code content...
  $scope.aceModel = ';; Scheme code in here.\n' +
    '(define (double x)\n\t(* x x))\n\n\n' +
    '<!-- XML code in here. -->\n' +
    '<root>\n\t<foo>\n\t</foo>\n\t<bar/>\n</root>\n\n\n' +
    '// Javascript code in here.\n' +
    'function foo(msg) {\n\tvar r = Math.random();\n\treturn "" + r + " : " + msg;\n}';

});

function AceCtrl($scope) {

}
