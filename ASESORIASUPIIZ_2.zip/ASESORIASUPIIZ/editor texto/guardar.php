<?php
$Nombre   = $_POST['Nombre'];
$programa = $_POST['programa'];
$carpeta  = $_POST['carpeta'];
$programa = str_replace("\n", "\r\n", $programa);
$file     = fopen($carpeta . "/" . $Nombre . ".java", "w");
$a        = fwrite($file, $programa);
if (!$a) {
    echo "ERROR ";
} else {
    echo "Guardado.. ";
}
?>