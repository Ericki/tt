function descriocion(descri)
{  

    var mensaje =$("#des");
    var formData= descri;
        var parametros = {
                "descri" : descri      
        };
        $.ajax({
                data:  parametros,
                url:   '../partials/descripcion.php',
                type:  'post',

        }).done(function(msg){  
            mensaje.html(msg);    
           }).fail( function( jqXHR, textStatus, errorThrown ) {
    mensaje.html("Estamos teniendo problemas");
});
}
function editar(ids)
{  
    var mensaje =$("#des");
        var parametros = {
                "id" : ids          
        };
        $.ajax({
                data:  parametros,
                url:   '../partials/EditarDescripcion.php',
                type:  'post',

        }).done(function(msg){  
            mensaje.html(msg);    
           }).fail( function( jqXHR, textStatus, errorThrown ) {
    mensaje.html("Estamos teniendo problemas");
});
}
function editar1(id)
{ 
    var descri = document.Edit.descripcion.value;
   
    var mensaje =$("#des");
        var parametros = {
                "descri" : descri,
                "id": id
        };
        $.ajax({
                data:  parametros,
                url:   '../partials/EditarDescripcion_1.php',
                type:  'post',
        }).done(function(msg){  
             
           $(".upload-msg").html(data);
            window.setTimeout(function() {
            $(".alert-dismissible").fadeTo(500, 0).slideUp(500, function(){
            $(this).remove();
            }); }, 5000);   
           })
}

function buscar(id){
var nombre = document.BA.Nombrea.value;  
        var parametros = {
                "nombre" : nombre,
                "id": id
        };
        $.ajax({
                data:  parametros,
                url:   '../partials/busquedatemario.php',
                type:  'post',
        }).done(function(msg){ 
                document.getElementById('busqueda').innerHTML = msg;  
         
           })       
}  

