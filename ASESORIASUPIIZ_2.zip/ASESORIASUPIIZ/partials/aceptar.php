
<?php 
$v1 = $_GET['variable1'];
require('../php/conexion.php');
$sql = "UPDATE `temario` SET `estatus` = 'aceptado' WHERE `temario`.`direccion_doc` = :DOC";	
	$resultado=$base->prepare($sql);
	$resultado->bindValue(":DOC", $v1);
$resultado->execute();
session_start();
if ($_SESSION['tipo_usuario']!='Administrador')  {
      header("Location:SuperTemario2.php");
    
 }else{header("Location:SuperTemario.php");}
	

				?>