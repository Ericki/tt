<style type="text/css">
	.ace_editor { height: 300px; }
</style>

<section ng-controller="AceCtrl">
	<h3>Numero de asesoria {{asesoria}}</h3>
<!--<h6 ng-repeat="datas in asesorias ">{{asesoria==datas.id_asesorias}}<button type="button" name="" ng-click="editorAsesoria(datas)" ng-init="userf(datas.id_asesorado);">{{datas}} chatear con {{points[$index].id_usuario}}</button> </h6>
-->
<div class="row" ng-show="false">
	<div  ng-repeat="message in asesorias" ng-show="listaAsesorias" ng-init="userf(message.id_asesor);" class="col s4" >
			<div class="card horizontal">
				<div class="card-image col s4" >
					<img  ng-src="../php/{{points[$index].foto}}">
				</div>
				<div class="card-stacked">
					<div class="card-content">
					 <span class="card-title activator grey-text text-darken-4">{{points[$index].usuario}}<i class="material-icons right">more_vert</i></span>
					</div>

					<div class="card-action">
					 <a ng-click="">Borrar</a>
					 <a ng-model="message.text" ng-change="messages.$save(message)"  ng-click="editorAsesoria(message)">Iniciar</a>
				 </div>
				</div>
				<div class="card-reveal">
				 <span class="card-title grey-text text-darken-4">Descripcion<i class="material-icons right">close</i></span>
				 <p>{{points[$index].nombre}}</p>
				 <p>Lenguaje {{message.usuario}}</p>
				 </div>
			</div>
		</div>
</div>

<div class="row" >
	<div  ng-repeat="message in asesorias" ng-show="listaAsesorias" ng-init="userf(message.id_asesorado);" class="col s4" >
			<div class="card horizontal">
				<div class="card-image col s4" >
					<img  ng-src="../php/{{points[$index].foto}}">
				</div>
				<div class="card-stacked">
					<div class="card-content">
					 <span class="card-title activator grey-text text-darken-4">{{points[$index].usuario}}<i class="material-icons right">more_vert</i></span>
					</div>

					<div class="card-action">
					 <a ng-click="">Borrar</a>
					 <a ng-model="message.text" ng-change="messages.$save(message)"  ng-click="editorAsesoria(message)">Iniciar</a>
				 </div>
				</div>
				<div class="card-reveal">
				 <span class="card-title grey-text text-darken-4">Descripcion<i class="material-icons right">close</i></span>
				 <p>{{points[$index].nombre}}</p>
				 <p>Lenguaje {{message.usuario}}</p>
				 </div>
			</div>
		</div>
</div>



<select ng-model="mode" ng-options="m for m in modes" ng-change="modeChanged()"></select>

<form ng-show="(!listaAsesorias) && (!editorActivador)">
	<button ng-click="addMessage()"><i class="material-icons right"  ng-show="!listaAsesorias">note_add</i> Documento</button>
	<button ng-click="listaAsesorias=true"> Asesorias</button>
</form>
 <div class="row">

	 <div  ng-repeat="message in messages" ng-show="(asesoria==message.asesoria) && (!editorActivador) && (!listaAsesorias)"  class="col s4">
	     <div class="card horizontal">
	       <div class="card-image col s4" ng-show="message.lenguaje=='c'">
	         <img  src="../img/C-language.png">
	       </div>
				 <div class="card-image col s4" ng-show="message.lenguaje=='java'">
	         <img  src="../img/java_logo.png">
	       </div>
	       <div class="card-stacked">
	         <div class="card-content">
	 					<span class="card-title activator grey-text text-darken-4">{{message.nombre}}<i class="material-icons right">more_vert</i></span>
	         </div>

	         <div class="card-action">
	 					<a ng-click="messages.$remove(message)">Borrar</a>
	 					<a ng-model="message.text" ng-change="messages.$save(message)" ng-keyup="fAgrega(message.text) " ng-click="e(message)">Editar</a>
	 				</div>
	       </div>
				 <div class="card-reveal">
					<span class="card-title grey-text text-darken-4">Descripcion<i class="material-icons right">close</i></span>
					<p>{{message.descripcion}}</p>
					<p>Lenguaje {{message.lenguaje}}</p>
					</div>
	     </div>
	   </div>


 </div>
<!-- delete a message -->





	<div ng-show="editorActivador">

		<h6>{{nombrePrograma}}</h6>

		<!--onkeyup="fAgrega();"-->
	<button class="waves-effect waves-light btn light-blue" ng-show="editor.lenguaje=='java'" ng-click="openChat(asesoria)"> <i class="material-icons">send</i> </button>
	<button class="waves-effect waves-light btn red accent-4" ng-show="editor.lenguaje=='java'"  ng-click="editorActivador=false"><i class="material-icons">stop</i></button>
	<button  class="waves-effect waves-light btn green accent-4" ng-show="editor.lenguaje=='java'"   ng-click="CompilaN(editor)" ><i class="material-icons">play_arrow</i></button>
	<button class="waves-effect waves-light btn light-blue" ng-show="editor.lenguaje=='c'" ng-click="openChat(asesoria)"> <i class="material-icons">send</i> </button>
	<button class="waves-effect waves-light btn red accent-4" ng-show="editor.lenguaje=='c'"  ng-click="editorActivador=false"><i class="material-icons">stop</i></button>
	<button id="Compila" value="{{usuario.id_usuario}}" class="waves-effect waves-light btn green accent-4" ng-show="editor.lenguaje=='c'"  ng-click="CompilaNC(editor)"><i class="material-icons">play_arrow</i></button>

<div ui-ace="aceOption" ng-model="editor.text" ng-change="messages.$save(editor)" ></div>
		<!--<button id="Programar" value="2" ng-click="programar()">programar</button>-->
		<span>Compilado por </span><span ng-show="!editor.compiladoPor=usuario.nombre" ng-model="editor.compiladoPor" class="red-text text-darken-4">{{usuario.nombre}}</span>

<textarea rows="4"cols="100" ng-model="editor.resultado">Aquí se imprimirá la respuesta</textarea>
</div>


</section>
