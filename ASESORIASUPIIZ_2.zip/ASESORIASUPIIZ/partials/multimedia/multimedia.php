<?php
session_start();
if (!isset($_SESSION['usuario'])) {
  header("Location:../index.html");
}else{
if ($_SESSION['estado']!= 'Alta')  {
header("Location:espera.php");
}
}
?>

<?php if ($_SESSION['tipo_usuario']=='Administrador' || $_SESSION['tipo_usuario']=='Asesor')  {
echo '
<div class="container"  style="  background-color:#29C5D6;" >
  <div>

         <div class="col-md-6 col-md-offset-3">
          <div class="text-center">
      <form id="datosT" method="post" accept-charset="utf-8">
    <div class="form-group">
    <label for="exampleInputFile">Postear video</label>
     <input id="link" name="link" type="text" placeholder="Url del video de youtube" class="form-control" required/>

     <br/>
<br/>
<label for="exampleInputFile">Titulo del video</label>
     <input id="titulo" name="titulo" type="text" placeholder="Titulo del video no mas de 50 caracteres" class="form-control" required/>

      <br/>
<br/>
<label for="exampleInputFile">Descrpcion del video </label>
     <input id="descripcion" name="descripcion" type="text" placeholder="Descripcion del video no mas de 100 caracteres" class="form-control" required/>

    </div>
          <br/>
<br/>
<button id="todos" name="todos" type="submit" value="todos" onclick="multimedia()" class="btn btn-primary btn-lg" ;>Postear</button>

     <div class="upload-msg"></div><!--Para mostrar la respuesta del archivo llamado via ajax -->
  </form>
    </div>
      </div>
  </div>
  </div>';
} ?>

<div class="container-fluid text-center">
<h1> Seccion de multimedia </h1>

</div>
<div class="container-fluid">
<div  class="col-md-12" name="multi" id="multi"  style="
height: 500px;
overflow:scroll;
overflow-x: hidden;
visibility: visible;
" >


</div>


</div>


<div></div>


 <div  class="container ">
  <div class="col-md-6 col-md-offset-3">
          <div class="text-center">
      <form id="BM" name="BM" method="post" accept-charset="utf-8">
               <div class="form-group">
    <label for="exampleInputFile">Buscar archivo</label>
     <input id="Nombrea" name="Nombrea" type="text" placeholder="Nombre del archivo" class="form-control">
     <br/>
<br/>
<button id="Buscar" type="submit" name="Buscar"   onclick="buscarmultimedia()"  value="Buscar" class="btn btn-primary btn-lg" ;>Buscar</button>
  </div>
  </form>

      </div>
       </div>
</div>

<div class="container-fluid">
<div  class="col-md-12" name="busqueda" id="busqueda"  style="
height: 200px;
overflow:scroll;
overflow-x: hidden;
visibility: visible;
" >

</div>

</div>


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
