<?php
//$host = 'localhost';
//$usuario = 'root';
//$pass = '';
try {
    //$base = new PDO('mysql:host=localhost; dbname=asesorias', 'root', '');
     $base = new PDO('mysql:host=mysql.hostinger.mx; dbname=u749281552_aseso', 'u749281552_aseso', 'trabajoterminal2');
    $base->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $base->exec("set names utf8");
} catch (Exception $e) {
    die('Error' . $e->getMessage());
    echo " Línea de error" . $e->getLine();
}

//$link=mysql_connect($host, $usuario, $pass)or die("¡Imposible conectar!");
//mysql_select_db("baseasesorias", $link)or die("Ups!, no se encuentra la BD");
