var chat = angular.module("Chat", []);
chat.factory("services", ['$http', function($http) {
  var serviceBase = '../services/'
  var obj = {};
  obj.getCustomers = function(){return $http.get(serviceBase + 'customers');}
  obj.getAsesorias = function(){return $http.get(serviceBase + 'asesorias');}
  obj.getUsuarios = function(){return $http.get(serviceBase + 'usuarios');}
  obj.getCustomer = function(customerID){return $http.get(serviceBase + 'customer?id=' + customerID);}
  obj.insertAsesorias = function (customer) {return $http.post(serviceBase + 'crearAsesorias', customer).then(function (results) {return results;});};
  obj.insertCustomer = function (customer) {return $http.post(serviceBase + 'insertCustomer', customer).then(function (results) {return results;});};
  obj.updateCustomer = function (id,customer) {return $http.post(serviceBase + 'updateCustomer', {id:id, customer:customer}).then(function (status) {return status.data;});};
  obj.deleteCustomer = function (id) {return $http.delete(serviceBase + 'deleteCustomer?id=' + id).then(function (status) {return status.data;});};
  obj.getMensajesChat = function(conversacionID){return $http.get(serviceBase + 'mensajesChat?id='+conversacionID );}
  obj.insertarMensaje = function (mensaje) {return $http.post(serviceBase + 'insertMensaje', mensaje).then(function (results) {return results;});};
  obj.getMensaje = function(conversacionID){return $http.get(serviceBase + 'mensaje?id=' + conversacionID);}
  return obj;
}]);

chat.controller('chatCtrl', function ($scope, services) {
      $scope.init = function (user) {
        services.getCustomer(user).then(function(data){
            $scope.usuario = data.data;
            alert($scope.usuario)
        });
      };
      angular.element(document).ready(function () {//start jquery
        $scope.points=[];//usuarios que estan en las asesorias
        $scope.customers={};
        $scope.asesorias = {};

        services.getCustomers().then(function(data){
          $scope.customers = data.data;
          angular.copy(data.data, $scope.customers);
        });

        $scope.obtenerAsesorados = function(user){
          $scope.as = angular.copy($scope.customers);
          $scope.ase = angular.copy($scope.asesorias);
          var asesoriasUser = [];
          var aU = [];
          var length = $scope.ase.length;
          var verificador = 0;
          for (i = 0; i < length; i++) {
            if($scope.ase[i].id_asesor==user)
            asesoriasUser.push($scope.ase[i]);
          };
          for (i = 0; i < $scope.as.length; i++) {
            for (j = 0; j < asesoriasUser.length; j++) {
              if(asesoriasUser[j].id_asesorado==$scope.as[i].id_usuario){
                verificador++;}
            };
            if(verificador==0){
              aU.push($scope.as[i]);
            }
            verificador=0;
            };

          $scope.nuevosAsesorias = asesoriasUser;
          $scope.asesoradosSinAsesoria = aU;
        }
        $scope.obtenerAsesores = function(user){
          $scope.as = angular.copy($scope.customers);
          $scope.ase = angular.copy($scope.asesorias);
          var asesoriasUser = [];
          var aU = [];
          var length = $scope.ase.length;
          var verificador = 0;
          for (i = 0; i < length; i++) {
            if($scope.ase[i].id_asesor==user)
            asesoriasUser.push($scope.ase[i]);
          };
          for (i = 0; i < $scope.as.length; i++) {
            for (j = 0; j < asesoriasUser.length; j++) {
              if(asesoriasUser[j].id_asesorado==$scope.as[i].id_usuario){
                verificador++;}
            };
            if(verificador==0){
              aU.push($scope.as[i]);
            }
            verificador=0;
            };

          $scope.nuevosAsesorias = asesoriasUser;
          $scope.ases = aU;

        }
        $scope.o = function(user){
          alert(user)
          $scope.asq = angular.copy($scope.customers);
          $scope.aseq = angular.copy($scope.asesorias);
          console.log($scope.asq);
          console.log($scope.aseq);

          var asesoriasUser = [];
          var aU = [];
          var length = $scope.aseq.length;
          var verificador = 0;
          for (i = 0; i < length; i++) {
            if($scope.aseq[i].id_asesorado==user)
            asesoriasUser.push($scope.aseq[i]);
            //alert(JSON.stringify($scope.aseq[i]))
          };
          for (i = 0; i < $scope.asq.length; i++) {
            for (j = 0; j < asesoriasUser.length; j++) {
              if(asesoriasUser[j].id_asesor==$scope.asq[i].id_usuario){
                verificador++;}
            };
            if(verificador==0){
              aU.push($scope.asq[i]);
              //alert($scope.asq[i])
            }
            verificador=0;
            };

          $scope.w = asesoriasUser;
          $scope.d = aU;

        }

        services.getAsesorias().then(function(data){
            $scope.asesorias = data.data;
            angular.copy(data.data, $scope.asesorias);
        });

        $scope.hacerAsesorias = function(asesor,asesorado){
          alert(asesor+ '  ' +asesorado);
          var m = {'id_asesor': asesor,'id_asesorado': asesorado};
          services.insertAsesorias(m);
        }

        $scope.userf = function(user){
          services.getCustomer(user).then(function(data){
              $scope.u = data.data;
              $scope.points.push($scope.u)
          });
          return $scope.u;
        }


        var user;
         $scope.messages = [{'mensaje': '' ,'hora_mensaje': '','id_conversacion' : ''}];
        var activation = false;
        var messages_template = Handlebars.compile($('#messages-template').html());
        var messages_html = [];
        function updateMessages(msg){
          if ($scope.messages[0] == null){
            $scope.messages = [{'mensaje': '' ,'hora_mensaje': '','id_conversacion' : ''}];
            //console.log($scope.messages);
          }
          $scope.messages.push(msg);
           messages_html = messages_template({'messages': $scope.messages});
          $('#messages').html(messages_html);
          $("#messages").animate({ scrollTop: $('#messages')[0].scrollHeight}, 1000);
        }
        var conn = new WebSocket('ws://192.168.1.108:8080');conn.onopen = function(e) {};
        conn.onmessage = function(e) {var msg = JSON.parse(e.data);alert(JSON.stringify(msg.message));updateMessages(msg.message);};

        $scope.openChat = function(conversacion) {
          alert(conversacion)
          services.getMensajesChat(conversacion).then(function(data){
          $scope.mensajesAlmacenados = data.data;
          $scope.messages = $scope.mensajesAlmacenados;
          messages_html = messages_template({'messages': $scope.messages});

          });

          activation = !activation;
          if (activation==true) {user = conversacion;$('#user-container').addClass('hidden');$('#container-asesorados').addClass('hidden');$('#main-container').removeClass('hidden');}
          else {$('#main-container').addClass('hidden');}
          var msg = {
            'mensaje': user + ' esta conectado',
            'hora_mensaje': moment().format('hh:mm a'),
            'id_conversacion' : conversacion
          };
          updateMessages(msg);
          var channel = conversacion;
             conn.send(JSON.stringify({command: "subscribe", channel: channel}));
          $('#user').val('');

          $scope.Press = function(e) {

            if(e.which == 13) {
                var text = $('#msg').val();
                var msg = {
                  'mensaje': text ,
                'hora_mensaje': moment().format('hh:mm a'),
                'id_conversacion' : conversacion
                };
                //alert(conversacion);
                services.insertarMensaje(msg);
                alert(JSON.stringify(msg));
                updateMessages(msg);
                 conn.send(JSON.stringify({command: "message", message: msg}));
                $('#msg').val('');
            }
        };

        };




        $('#leave-room').click(function(){
          var msg = {'user': user,'mensaje': user + ' has left the room','time': moment().format('hh:mm a')};
          updateMessages(msg);
          $('#messages').html('');messages = [];
          $('#main-container').addClass('hidden');
          $('#user-container').removeClass('hidden');
        });
      });

});


//chat.controller('TestCtrl', function($scope) {alert('testChat perros');});
