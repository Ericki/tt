
function buscarmultimedia() {
    var nombre = document.getElementById("Nombrea").value;
    var mensaje = $("#busqueda");
    var parametros = {
        "nombre": nombre
    
    };
    alert(nombre);
    $.ajax({
        data: parametros,
        url: '../php/buscarmultimedia.php',
        type: 'post',
    }).done(function(msg) {
        mensaje.html(msg);
    }).fail(function(jqXHR, textStatus, errorThrown) {
        mensaje.html("Estamos teniendo problemas");
    });
}
