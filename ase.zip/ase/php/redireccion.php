<?php 
	session_start();
	if (!isset($_SESSION['usuario']) ) {
		header("Location:../partials/login.html");
	}else{
		switch ($_SESSION['tipo_usuario']) {
			case 'Administrador':
				header("Location:../partials/inicioAdministrador.php");
				break;
			case 'Asesor':
				header("Location:../partials/inicioAsesor.php");
				break;
			case 'Alumno Asesor':
				header("Location:../partials/inicioAlumnoAsesor.php");
				break;
			default:
				header("Location:../partials/inicioAsesorado.php");
				break;
		}

	}?>

