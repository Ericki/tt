
<?php 
$v1 = $_GET['variable1'];
require('conexion.php');
$sql = "DELETE FROM `multimedia` WHERE `multimedia`.`id_multi` =  :DOC";	
	$resultado=$base->prepare($sql);
	$resultado->bindValue(":DOC", $v1);
$resultado->execute();
header('Location: ../partials/multimedia.php');

	

				?>