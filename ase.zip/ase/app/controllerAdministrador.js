var administrador = angular.module("Administrador", []);
administrador.factory("services", ['$http', function($http) {
  var serviceBase = '../services/'
    var obj = {};
    obj.getCustomers = function(){
        return $http.get(serviceBase + 'customers');
    }
    obj.getUsuarios = function(){
        return $http.get(serviceBase + 'usuarios');
    }
    obj.getCustomer = function(customerID){
        return $http.get(serviceBase + 'customer?id=' + customerID);
    }


    return obj;

}]);

//administrador.controller('TestCtrl', function($scope) {alert('testAdministrador perros');});
administrador.controller('listCtrl', function ($scope, services) {
    services.getCustomers().then(function(data){
        $scope.customers = data.data;
    });
});
administrador.controller('listUsuariosCtrl', function ($scope, services) {
    services.getUsuarios().then(function(data){
        $scope.customers = data.data;
    });
});
