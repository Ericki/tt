var perfil = angular.module("Perfil", []);
perfil.factory("services", ['$http', function($http) {
  var serviceBase = '../services/'
    var obj = {};
    obj.getCustomers = function(){
        return $http.get(serviceBase + 'customers');
    }
    obj.getUsuarios = function(){
        return $http.get(serviceBase + 'usuarios');
    }
    obj.getCustomer = function(customerID){
        return $http.get(serviceBase + 'customer?id=' + customerID);
    }


    return obj;

}]);

//perfil.controller('TestCtrl', function($scope) {alert('testperfil perros');});
