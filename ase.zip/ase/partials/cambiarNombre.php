<?php  
require('../php/conexion.php');
$descripcion= $_POST['nomb'];

	$sql = 'SELECT * FROM `ejercicios` WHERE `id_ejercicios`=:id';
	$resultado=$base->prepare($sql);
    $resultado->bindValue(":id", $descripcion);
    $resultado->execute();
    $descri= $resultado->fetch();
echo '<h6>'.$descri['nombre_ej'].'</h6>';

?>

