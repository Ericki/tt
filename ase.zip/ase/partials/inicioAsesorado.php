<?php
session_start();
    if (!isset($_SESSION['usuario']) ) {
    header("Location:../php/redireccion.php");
}else{
    if ($_SESSION['tipo_usuario']!= 'Asesorado')   {
    header("Location:../php/redireccion.php");
 }else{
    if ($_SESSION['estado']!= 'Alta')  {
    header("Location:espera.php");
 }
}
}
$_SESSION['id'];
  ?>
 <!DOCTYPE html>
<html ng-app="myApp" ng-app lang="es">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">


            <link data-require="bootstrap-css@2.3.2" data-semver="2.3.2" rel="stylesheet" href="../css/bootstrap-combined.min.css" />
            <script data-require="angular.js@1.1.5" data-semver="1.1.5" src="../js/jquery/angular.min.js"></script>
            <script data-require="angular-ui-bootstrap@0.3.0" data-semver="0.3.0" src="../js/ui-bootstrap-tpls-0.3.0.min.js"></script>

                    <!-- Bootstrap Core CSS -->
                    <link href="../css/menutemario.css" rel="stylesheet">
                    <!-- Bootstrap Core CSS -->
                    <link href="../css/tamano.css" rel="stylesheet">
                    <link href="../fonts/icon.css" rel="stylesheet">
                    <!-- Bootstrap Core CSS -->
                    <link href="../css/bootstrap.min.css" rel="stylesheet">
                    <!-- Theme CSS -->
                    <link href="../css/freelancer.min.css" rel="stylesheet">
                    <!-- Custom Fonts -->
                    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
                    <link href="../fonts/icon2.css" rel="stylesheet" type="text/css">
                    <link href="../fonts/icon3.css" rel="stylesheet" type="text/css">
                    <!--ng-table-->
                    <link rel="stylesheet"; href="../css/ng-table.min.css">
                    <link rel="stylesheet" href="../chat/css/style.css">

                  	<script src="../js/jquery.min.js"></script>
                  	<script src="../js/handlebars.min.js"></script>
                    <script src="../js/moment.min.js"></script>
                   <link href="../css/css/materialize.min.css" rel="stylesheet">
                   <script type="text/javascript" src="../js/bootstrap-filestyle.min.js"> </script>
                   <script type="text/javascript" src="../js/temarioasesorado.js"></script>
                   <script type="text/javascript" src="../js/SuperTemario.js"></script>
                   <script type="text/javascript" src="../js/SuperTemario_2.js"></script>
                   <script type="text/javascript" src="../js/multimedia.js"></script>
                   <script type="text/javascript" src="../js/buscarmultimedia.js"></script>
                   <script type="text/javascript" src="../js/temarioasesorado.js"></script>

    <style type="text/css">
    ul>li, a{cursor: pointer;}
    </style>

    <title>Asesorias en linea UPIIZ-IPN</title>
</head>
<body id="page-top" class="index" ng-controller="chatCtrl" data-ng-init="init(<?php echo $_SESSION['id']; ?>)">
    <!-- Navigation -->
    <ul id="foro" class="dropdown-content">
      <li><a href="#foro/java">Para Java</a></li>
      <li class="divider"></li>
      <li><a href="#foro/c">Para C</a></li>
    </ul>
    <ul id="programar" class="dropdown-content">
      <li><a href="#editor">Editor Java</a></li>
      <li class="divider"></li>
      <li><a href="#editor">Editor C</a></li>
    </ul>
   <nav class="nav-extended blue darken-4" >
  <div class="nav-wrapper lighten-2">
    <a href="#" class="brand-logo">Asesorado <img class="img-responsive" src="img/UPIIZ.png"></a>
    <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
    <ul id="nav-mobile" class="right hide-on-med-and-down lighten-2">
      <li><a href="#perfil/<?php echo $_SESSION['id']; ?>"><img ng-src="../php/{{usuario.foto}}" style="width: 30px; height: 30px; ">
            <span><?php echo $_SESSION['usuario'];?></span></a></li>
      <li><a class="dropdown-button" href="#!" data-activates="foro">Foro</a></li>
      <li><a href="#editor" data-activates="programar">Asesorias</a></li>
      <li><a href="#administrar-usuarios-asesor">Contenido</a></li>
      <li><a href="../php/salir.php">Salir</a></li>

    </ul>
    <ul class="side-nav" id="mobile-demo">
      <li><div class="userView">
        <div class="background">
          <img src="../img/fondo_perfil.jpg">
        </div>
        <a class="close white"><i class="large material-icons red-text text-darken-4">skip_previous</i></a>
        <a href="#perfil/<?php echo $_SESSION['id']; ?>"><img class="circle" ng-src="../php/{{usuario.foto}}"></a>
        <a href="#perfil/<?php echo $_SESSION['id']; ?>"><span class="white-text name">{{usuario.usuario}}</span></a>
      </div></li>
           <li class="no-padding">
             <ul class="collapsible collapsible-accordion">
               <li>
                 <a class="collapsible-header blue-text text-darken-2">Foro</a>
                 <div class="collapsible-body">
                   <ul>
                     <li><a href="#foro/java" class="blue-text text-darken-4">Java</a></li>
                     <li><a href="#foro/c" class="blue-text text-darken-4">C</a></li>
                   </ul>
                 </div>
               </li>
             </ul>
           </li>
           <li><div class="divider blue darken-4"></div></li>
           <li class="no-padding">
             <ul class="collapsible collapsible-accordion">
               <li>
                 <a class="collapsible-header blue-text text-darken-2">Asesorias</a>
                 <div class="collapsible-body">
                   <ul>
                     <li><a href="#editor" class="blue-text text-darken-4">Usuarios</a></li>
                   </ul>
                 </div>
               </li>
             </ul>
           </li>
           <li class="no-padding">
             <ul class="collapsible collapsible-accordion">
          <li><div class="divider blue darken-4"></div></li>
               <li>
                 <a class="collapsible-header blue-text text-darken-2">Contenido</a>
                 <div class="collapsible-body">
                   <ul>
                     <li><a class="waves-effect blue-text text-darken-4" href="#archivos">Archivos</a></li>
                     <li><a class="waves-effect blue-text text-darken-4" href="#ejercicios">Ejercicios</a></li>
                     <li><a class="waves-effect blue-text text-darken-4" href="#multimedia">Multimedia</a></li>
                   </ul>
                 </div>
               </li>
             </ul>
           </li>
           <li><a href="../php/salir.php">Salir</a></li>
         </ul>

  </div>

  </nav>

<!-- Header -->

    <div class="navbar navbar-default" id="navbar">
        <div class="container" id="navbar-container">
            <div class="navbar-header">
            </div><!-- /.navbar-header -->
             <!-- Modal Trigger -->
        </div>
    </div>

    <div>
      {{Asesor}}
        <div class="container-fluid">
          <!--<h6 ng-repeat="datas in asesorias "><button type="button" name="" ng-click="openChat(datas.id_asesorias)" ng-init="userf(datas.id_asesorado);"> chatear con {{points[$index].nombre}}{{datas}}</button> </h6>
        <h6 ><button type="button" name=""  ng-click="o('<?php echo $_SESSION['id']; ?>');"> Usuarios</button> </h6>
        <h6 ng-repeat="datas in d | filter :{tipo_usuario : '!Asesorado' }| filter :{tipo_usuario : 'Asesor' }  " >{{datas.tipo_usuario}}<button type="button" name="" ng-click="hacerAsesorias(datas.id_usuario,'<?php echo $_SESSION['id']; ?>')" >Hacer Asesorado a {{datas.usuario}}</button></h6>
        -->
            <div ng-view="" id="ng-view"></div>
        </div>
    </div>
    <!-- chat -->
    {{mostrarChat}}
    <!-- chat -->

                <div class="conteiner" ng-show="mostrarChat">
                  <div class="row">
                    <div id="wrapper" class="">
                      <div id="user-container" >
                      </div>

                      <div id="main-container" class="hidden blue lighten-4" >
                        <button type="button" id="leave-room" ng-click="mostrarChat=!mostrarChat">x</button>
                          <div id="messages">
                          </div>
                        <div class="input-field white">
                          <input id="msg" name="msg" type="text" class="validate "  placeholder="Escribe un mensaje..." ng-keypress="Press($event)" >
                        </div>
                      </div>
    <!--
                      <div id="main-container" class="">
                        <div class="card">
                          <div class="card-image waves-effect waves-block waves-light">
                            <img class="activator" src="">
                          </div>
                          <div class="card-content">
                            <div id="messages">
                              <div >
                                <ul class="collection with-header">
                                  <li class="collection-item" ng-repeat="datas in asesorias | filter:search" ><div> <img ng-src="../php/{{points[$index].foto}}" class="activator col s2">{{points[$index].nombre}} <a class="secondary-content" ng-click="openChat(datas.id_asesorias)" ng-init="userf(datas.id_asesorado);"><i class="material-icons">send</i></a></div></li>
                                </ul>
                              </div>
                            </div>
                          </div>
                          <div class="card-reveal">
                            <span class="card-title grey-text text-darken-4">Card Title<i class="material-icons right">close</i></span>
                            <p>Here is some more information about this product that is only revealed once clicked on.</p>
                          </div>
                        </div>
                          <div class="input-field">
                            <i class="material-icons prefix">search</i>
                            <input id="icon_prefix" ng-model="search" type="text" class="validate" placeholder="Busca">
                            <label for="icon_prefix">Busca</label>
                          </div>
                      </div>
                    -->
                    </div>
                  </div>
                </div>
          </div>

              <script id="messages-template" type="text/x-handlebars-template">
                {{#each messages}}
                <div class="msg">
                  <div class="time">{{time}}</div>
                  <div class="details">
                    <ul class="collection with-header">
                      <li class="collection-item avatar">
                        <img src="{{usuario.foto}}" alt="" class="circle">
                        <span class="title">{{usuario.usuario}}</span>
                        <p>{{mensaje}}</p>
                      </li>
                    </ul>
                  </div>
                </div>
                {{/each}}
              </script>
              <div id="mensaje"></div>

          <!-- fin -->


      <!-- Footer -->
      <footer class="page-footer blue darken-2">
                <div class="container">
                  <div class="row">
                    <div class="col l6 s12">
                      <h5 class="white-text">Asesorias en linea UPIIZ-IPN</h5>
                      <p class="grey-text text-lighten-4">Plataforma web para facilitar las asesorías de programación C y Java</p>
                    </div>
                    <div class="col l4 offset-l2 s12">
                      <h5 class="white-text"></h5>
                      <ul>
                        <li><a class="grey-text text-lighten-3" href="#!"></a></li>
                        <li><a class="grey-text text-lighten-3" href="#!"></a></li>
                        <li><a class="grey-text text-lighten-3" href="#!"></a></li>
                        <li><a class="grey-text text-lighten-3" href="#!"></a></li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="footer-copyright blue darken-4">
                  <div class="container">
                  © 2014 Copyright Text
                  <a class="grey-text text-lighten-4 right" href="#!"></a>
                  </div>
                </div>
              </footer>
    <!-- jQuery -->
    <script src="../js/jquery/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>
    <!-- Plugin JavaScript -->
    <script src="../js/jquery.easing.min.js"></script>
    <!-- Contact Form JavaScript -->
    <script src="../js/jqBootstrapValidation.js"></script>
    <script src="../js/contact_me.js"></script>
    <!-- Theme JavaScript -->
    <script src="../js/freelancer.min.js"></script>
    <script src="../js/moment/moment.min.js"></script>
    <script src="../js/ng-table.min.js"></script>
    <script src="../js/jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="../bower_components/ace-builds/src-min-noconflict/ace.js"></script>
    <script type="text/javascript" src="../bower_components/angular/angular.js"></script>
    <script type="text/javascript" src="../bower_components/angular-ui-ace/ui-ace.js"></script>
    <script type="text/javascript" src="../bower_components/ace-builds/src-min-noconflict/ext-language_tools.js"></script>
    <script src="../js/angular.min.js"></script>
    <script src="../js/angular-route.min.js"></script>
    <script src="../js/moment/moment.min.js"></script>
    <script src="../js/moment/angular-moment.js"></script>
    <script src="../css/js/materialize.min.js"></script>
    <script src="../js/firebase.js"></script>
    <script src="../js/angularfire.min.js"></script>
    <script type="text/javascript" src="../editor texto/Compilar.js"></script>
    <script src="../editor texto/Editor.js"></script>
    <script src="../app/controllerAdministrador.js"></script>
    <script src="../app/controllerForo.js"></script>
    <script src="../app/controllerEditor.js"></script>
    <script src="../app/controllerChat.js"></script>
    <script src="../app/controllerPerfil.js"></script>
    <script>
    $( document ).ready(function(){$(".button-collapse").sideNav(); $(".dropdown-button").dropdown();
    $( ".close" ).click(function() {
     $('.button-collapse').sideNav('hide');});
    });

    </script>
    <script src="../app/app.js"></script>
</body>
</html>
