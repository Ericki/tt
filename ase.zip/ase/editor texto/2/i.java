// Clase principal iniciadora del programa ejemplo aprenderaprogramar.com

public class i {

    public static void main (String [ ] args) {
    int x = 0;
        System.out.println ("Empezamos la ejecución del programa");
        System.out.println (x);
 

    } //Cierre del main

} //Cierre de la clase