//Programa de asesorias ProgramaJava
// Clase principal iniciadora del programa ejemplo en java
public class ProgramaJava {
public static void main (String [ ] args) {
//Aquí las instrucciones de inicio y control del programa
for(int x=0 ;x<9;x++)
System.out.println ("Hola que pasa noda");
System.out.println
} //Cierre del main
} //Cierre de la clase';