//Programa de asesorias ProgramaSE
// Clase principal iniciadora del programa ejemplo en java
public class ProgramaSE {
public static void main (String [ ] args) {
//Aquí las instrucciones de inicio y control del programa
System.out.println ("Empezamos la ejecución del programa ProgramaSE");
} //Cierre del main
} //Cierre de la clase';