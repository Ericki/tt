#include <stdio.h>

int main(){
    
    for(int x = 3;x<30;x++){
        printf("Hola mundo,%d\n",x);
    }
        return 0;
}