//Programa de asesorias F22
// Clase principal iniciadora del programa ejemplo en c
#include <stdio.h>
int main(int argc, const char * argv[]){
//CICLOS FOR EN C
for(int x=2;x<20;x+=2){
printf("El contador X vale: %d\n",x);
}//fin de for 
 return 0;

}//fin de main