<?php
$var1 = $_POST['carpeta'];
$file = fopen("1/".$var1, "r");
while(!feof($file)) {
echo fgets($file);
}
fclose($file);

?>