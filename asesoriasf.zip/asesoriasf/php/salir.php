<?php
//Reanudamos la sesión
session_start();
//Requerimos los datos de la conexión a la BBDD
require('conexion.php');
$fechaGuardada            = $_SESSION['ultimoAcceso'];
$ahora                    = date("Y-n-j H:i:s");
$tiempo_transcurrido      = (strtotime($ahora) - strtotime($fechaGuardada));
$_SESSION['ultimoAcceso'] = $ahora;
switch ($_SESSION['biene']) {
    case "foroc":
        $_SESSION['foroc'] = $_SESSION['foroc'] + $tiempo_transcurrido;
        break;
    case "foroj":
        $_SESSION['foroj'] = $_SESSION['foroj'] + $tiempo_transcurrido;
        break;
    case "chat":
        $_SESSION['chat'] = $_SESSION['chat'] + $tiempo_transcurrido;
        break;
    case "programarc":
        $_SESSION['programarc'] = $_SESSION['programarc'] + $tiempo_transcurrido;
        break;
    case "programarj":
        $_SESSION['programarj'] = $_SESSION['programarj'] + $tiempo_transcurrido;
        break;
    default:
        // code...
        break;

}
$_SESSION['fecha'] = date("Y-n-j");
//$_SESSION["biene"]
$sentencia = $base->prepare("INSERT INTO tiempoasesorias (id_usuario, fecha, foroc, foroj, chat, programarc, programarj) VALUES (:usuario, :fecha, :foroc, :foroj, :chat, :programarc, :programarj);");
$sentencia->bindParam(':usuario', $_SESSION['id']);
$sentencia->bindParam(':fecha', $_SESSION['fecha']);
$sentencia->bindParam(':foroc', $_SESSION['foroc']);
$sentencia->bindParam(':foroj', $_SESSION['foroj']);
$sentencia->bindParam(':chat', $_SESSION['chat']);
$sentencia->bindParam(':programarc', $_SESSION['programarc']);
$sentencia->bindParam(':programarj', $_SESSION['programarj']);

$sentencia->execute();
//Des-establecemos todas las sesiones
unset($_SESSION);
//Destruimos las sesiones
session_destroy();
//Cerramos la conexión con la base de datos
mysqli_close($conexion);
//Redireccionamos a el index
header("Location:../index.html");
die();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Cerrando sesión...</title>
</head>
<body>
</body>
</html>
