<?php
session_start();
require 'conexion.php';
require 'fpdf/fpdf.php';
function caltiempo($tim)
{
    $t = ($tim - ($tim % 3600)) / 3600;
    if ($t == 0) {
        $tiempototal = "00:";
    } else {
        $tiempototal = $t . ":";
    }
    $t = $tim % 3600;
    $t = ($t - ($t % 60)) / 60;
    if ($t == 0) {
        $tiempototal = $tiempototal . "00:";
    } else {
        $tiempototal = $tiempototal . $t . ":";
    }
    $t           = $tim % 60;
    $tiempototal = $tiempototal . $t;
    return $tiempototal;
}

$fechainicio = $_POST['fechainicio'];
$fechafin    = $_POST['fechafin'];
$interesado  = $_POST['municipio'];

$pdf = new FPDF('L', 'mm', 'Letter');

$pdf->AddPage();
$pdf->Image('../img/fondo.jpeg', '0', '0', '280', '216', 'JPEG');
$pdf->Image('../img/logo.png', '120', '0', '50', '40', 'png');
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 65, utf8_decode("APLICACIÓN WEB PARA ASESORÍAS DE PROGRAMACIÓN DE LA UPIIZ"), 0, 0, 'C', false);

$pdf->Ln(8);
$pdf->SetFont('Arial', 'BI', 30);
$pdf->Cell(0, 100, utf8_decode("ESTE CERTIFICADO RECONOCE QUE"), 0, 0, 'C', false);
$pdf->SetLineWidth(1);
$pdf->Line(40, 75, 240, 75);
$pdf->Ln(8);
$pdf->SetFont('Arial', 'I', 12);

$resultado = $base->prepare('SELECT id_usuario, tipo_usuario, CONCAT (nombre," ",apellido_paterno," ",apellido_materno) as nom FROM `usuarios` WHERE CONCAT (nombre," ",apellido_paterno," ",apellido_materno) = "' . $interesado . '"');
$resultado->execute();
$registro        = $resultado->fetch();
$numero_registro = $resultado->rowCount();

if ($registro) {

    $resultado1 = $base->prepare("SELECT SUM(foroc+foroj+chat+programarc+programarj) as tiempo,SUM(foroc) as foroc,SUM(foroj) as foroj,SUM(chat) as chat,SUM(programarc) as programarc, SUM(programarj) as programarj FROM tiempoasesorias WHERE (fecha >= '" . $fechainicio . "' AND fecha <= '" . $fechafin . "')and id_usuario='" . $registro['id_usuario'] . "'");
    $resultado1->execute();
    $tiempo = $resultado1->fetch();

    $cadena2 = "Alumno Asesor";
    if (strcmp($registro['tipo_usuario'], $cadena2) !== 0) {
        $pdf->Cell(0, 110, utf8_decode("EL DOCENTE " . strtoupper($registro['nom'])), 0, 0, 'C', false);
        $pdf->Ln(7);
        if ($tiempo) {
            $pdf->Cell(0, 110, utf8_decode("HA DEDICADO " . caltiempo($tiempo['tiempo']) . " HORAS A DAR ASESORÍAS A  ALUMNOS DE LA UPIIZ"), 0, 0, 'C', false);
        } else {
            $pdf->Cell(0, 110, utf8_decode("HA DEDICADO 0 HORAS A DAR ASESORÍAS A  ALUMNOS DE LA UPIIZ"), 0, 0, 'C', false);

        }

    } else {
        $pdf->Cell(0, 110, utf8_decode("EL ALUMNO " . strtoupper($registro['nom'])), 0, 0, 'C', false);
        $pdf->Ln(7);
        if ($tiempo) {
            $pdf->Cell(0, 110, utf8_decode("HA DEDICADO " . caltiempo($tiempo['tiempo']) . " HORAS A DAR ASESORÍAS A OTROS ALUMNOS DE LA UPIIZ"), 0, 0, 'C', false);
        } else {
            $pdf->Cell(0, 110, utf8_decode("HA DEDICADO 0 HORAS A DAR ASESORÍAS A OTROS ALUMNOS DE LA UPIIZ"), 0, 0, 'C', false);

        }

    }

}

$pdf->Ln(7);
$pdf->Cell(0, 110, utf8_decode("EN EL PERIODO DE  " . $fechainicio . " A " . $fechafin), 0, 0, 'C', false);
$pdf->Ln(7);
$pdf->Cell(0, 110, utf8_decode("DISTRIBUIDAS EN LAS SIGUIENTES ACTIVIDADES:"), 0, 0, 'C', false);
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetXY(100, 110);
$pdf->SetFillColor(151, 190, 247);
$pdf->SetTextColor(255);

$pdf->SetDrawColor(4, 4, 4);
$pdf->SetLineWidth(.3);
$pdf->Cell(45, 7, "ACTIVIDAD", 1, 0, 'C', true);
$pdf->Cell(45, 7, "TIEMPO", 1, 0, 'C', true);
$pdf->Ln();
$pdf->SetXY(100, 117);
$pdf->SetTextColor(4, 4, 4);
$pdf->SetFillColor(0, 98, 244);
$pdf->SetDrawColor(4, 4, 4);
$pdf->SetLineWidth(.3);
$pdf->Cell(45, 7, "FORO C", 1, 0, 'C', true);
$pdf->SetFillColor(217, 255, 255);
if ($tiempo) {
    $pdf->Cell(45, 7, caltiempo($tiempo['foroc']), 1, 0, 'C', true);
} else {
    $pdf->Cell(45, 7, "00:00:00", 1, 0, 'C', true);

}

$pdf->Ln();
$pdf->SetXY(100, 124);
$pdf->SetFillColor(0, 98, 244);

$pdf->Cell(45, 7, "FORO JAVA", 1, 0, 'C', true);
$pdf->SetFillColor(217, 255, 255);

if ($tiempo) {
    $pdf->Cell(45, 7, caltiempo($tiempo['foroj']), 1, 0, 'C', true);
} else {
    $pdf->Cell(45, 7, "00:00:00", 1, 0, 'C', true);

}
$pdf->Ln();
$pdf->SetXY(100, 131);
$pdf->SetFillColor(0, 98, 244);

$pdf->Cell(45, 7, "CHAT", 1, 0, 'C', true);
$pdf->SetFillColor(217, 255, 255);

if ($tiempo) {
    $pdf->Cell(45, 7, caltiempo($tiempo['chat']), 1, 0, 'C', true);
} else {
    $pdf->Cell(45, 7, "00:00:00", 1, 0, 'C', true);

}
$pdf->Ln();
$pdf->SetXY(100, 138);
$pdf->SetFillColor(0, 98, 244);

$pdf->Cell(45, 7, "PROGRAMAR C", 1, 0, 'C', true);
$pdf->SetFillColor(217, 255, 255);

if ($tiempo) {
    $pdf->Cell(45, 7, caltiempo($tiempo['programarc']), 1, 0, 'C', true);
} else {
    $pdf->Cell(45, 7, "00:00:00", 1, 0, 'C', true);

}
$pdf->Ln();
$pdf->SetXY(100, 145);
$pdf->SetFillColor(0, 98, 244);

$pdf->Cell(45, 7, "PROGRAMAR JAVA", 1, 0, 'C', true);
$pdf->SetFillColor(217, 255, 255);

if ($tiempo) {
    $pdf->Cell(45, 7, caltiempo($tiempo['programarj']), 1, 0, 'C', true);
} else {
    $pdf->Cell(45, 7, "00:00:00", 1, 0, 'C', true);

}
$pdf->SetLineWidth(1);
$pdf->Ln();
$pdf->Line(100, 178, 180, 178);
$pdf->SetXY(90, 178);
$resultado3 = $base->prepare('SELECT id_usuario, tipo_usuario, CONCAT (nombre," ",apellido_paterno," ",apellido_materno) as nom FROM `usuarios` WHERE id_usuario = "' . $_SESSION['id'] . '"');

$resultado3->execute();
$nombre = $resultado3->fetch();

if ($nombre) {
    $pdf->Cell(100, 8, utf8_decode(strtoupper($nombre['nom'])), 0, 0, 'C', false);
} else {
    $pdf->Cell(100, 8, utf8_decode("XXXXXX XXXXXXXXX XXXXXXX XXXXX"), 0, 0, 'C', false);
}

$pdf->Ln();
$pdf->SetXY(90, 185);
$pdf->SetFont('Arial', 'BI', 14);
if ($nombre) {

    $cadena3 = "Administrador";
    if (strcmp($registro['tipo_usuario'], $cadena3) !== 0) {

        $pdf->Cell(100, 8, utf8_decode("ADMINISTRADOR RESPONSABLE"), 0, 0, 'C', false);

    } else {

        $pdf->Cell(100, 8, utf8_decode("ASESOR RESPONSABLE"), 0, 0, 'C', false);
    }
}

$pdf->Output('reporteAlumnos.pdf', 'D');
