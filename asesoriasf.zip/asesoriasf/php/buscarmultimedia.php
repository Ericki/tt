<?php
require '../php/conexion.php';
header("Content-Type: text/html;charset=utf-8");
session_start();
$sql    = 'SELECT * FROM `multimedia` WHERE `titulo`= "'.$_POST['nombre'].'"';
$result = $base->query($sql);
$rows   = $result->fetchAll();

if ($rows!=null) {
	foreach ($rows as $row) {

    echo '   <div class="col-md-5 fondo3 " style="margin:2px " >
<div class="container-fluid  " style="margin:2px " >
   <div class="col-md-6  " style=" font-size: 80%;">
   <iframe width="200" height="150" src="' . $row['linkvideo'] . '" frameborder="0" allowfullscreen></iframe>
   </div>
   <div class="col-md-6 text-center  " style=" word-wrap: break-word;">

   <h5>' . $row['titulo'] . '</h5>
   <p  style=" font: 100% sans-serif;" >'. $row['descripcion'] . '</p>
   </div>
  </div>';
  if ($_SESSION['tipo_usuario']=='Administrador' || $_SESSION['tipo_usuario']=='Asesor')  {
 echo'     <button id="todos" name="todos" type="submit" value="todos" onclick = "location=\'../php/borrarmulti.php?variable1=' . $row['id_multi'] . '\'"class="btn btn-primary btn-sm" ;>Borrar</button>

         </div>

  </div>';
} else{
	echo "No se encuentra ese video";
}



}
}
