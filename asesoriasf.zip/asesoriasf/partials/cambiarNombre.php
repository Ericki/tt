<?php  
require('../php/conexion.php');
$descripcion= $_POST['descri'];
	$sql = 'SELECT * FROM `ejercicios` WHERE `id_ejercicios`=:id';

	$resultado=$base->prepare($sql);
    $resultado->bindValue(":id", $descripcion);
    $resultado->execute();
    $descri= $resultado->fetch();
echo '<h6>'.$descri['descripcion'].'</h6>';

?>

