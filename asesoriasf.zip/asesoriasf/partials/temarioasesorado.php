<?php
session_start();
    if (!isset($_SESSION['usuario']) ) {
    header("Location:../index.html");
}else{
    if ($_SESSION['tipo_usuario']!='Asesorado')  {
    header("Location:..php/redireccion.php");
 }else{
    if ($_SESSION['estado']!= 'Alta')  {
    header("Location:espera.php");
 }
}
}
  ?>

  <!DOCTYPE html>
<html lang="es">

   <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">


        <link data-require="bootstrap-css@2.3.2" data-semver="2.3.2" rel="stylesheet" href="../css/bootstrap-combined.min.css" />
        <script data-require="angular.js@1.1.5" data-semver="1.1.5" src="../js/jquery/angular.min.js"></script>
        <script data-require="angular-ui-bootstrap@0.3.0" data-semver="0.3.0" src="../js/ui-bootstrap-tpls-0.3.0.min.js"></script>
        <!-- Bootstrap Core CSS -->
        <link href="../css/menutemario.css" rel="stylesheet">
        <!-- Bootstrap Core CSS -->
        <link href="../css/tamano.css" rel="stylesheet">
        <link href="../fonts/icon.css" rel="stylesheet">
        <!-- Bootstrap Core CSS -->
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <!-- Theme CSS -->
        <link href="../css/freelancer.min.css" rel="stylesheet">
        <!-- Custom Fonts -->
        <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="../fonts/icon2.css" rel="stylesheet" type="text/css">
        <link href="../fonts/icon3.css" rel="stylesheet" type="text/css">
        <!--ng-table-->
        <link rel="stylesheet"; href="../css/ng-table.min.css">
        <link rel="stylesheet" href="../chat/css/style.css">

        <script src="../js/jquery.min.js"></script>
        <script src="../js/handlebars.min.js"></script>
        <script src="../js/moment.min.js"></script>
        <link href="../css/css/materialize.min.css" rel="stylesheet">
        <script type="text/javascript" src="../js/bootstrap-filestyle.min.js"> </script>

     <script type="text/javascript" src="../js/temarioasesorado.js"></script>
     <script type="text/javascript" src="../js/SuperTemario.js"></script>
     <script type="text/javascript" src="../js/SuperTemario_2.js"></script>


        <style type="text/css">
            ul>li, a{cursor: pointer;}
        </style>

        <title>Asesorias en linea UPIIZ-IPN</title>
    </head>

<body id="page-top" class="index">

 <!-- Navigation -->
        <ul id="foro" class="dropdown-content">
          <li><a href="./inicioAsesorado.php#/foro/java">Para Java</a></li>
          <li class="divider"></li>
          <li><a href="./inicioAsesorado.php#/foro/c">Para C</a></li>
        </ul>

        <ul id="contenido" class="dropdown-content">
            <li><a href="ejercicios.php">Ejercicios</a></li>
            <li class="divider"></li>
            <li><a href="multimedia.php">Multimedia</a></li>
        </ul>

        <?php
          require('../php/conexion.php');
          $sql1 = 'SELECT * FROM `usuarios` WHERE `usuarios`.`id_usuario`=:id';
          $resultado1=$base->prepare($sql1);
          $resultado1->bindValue(":id",$_SESSION['id']);
          $resultado1->execute();
          $nombre1= $resultado1->fetch();
        ?>


        <nav class="nav-extended blue darken-4" >
        <div class="nav-wrapper lighten-2">
        <a href="#" class="brand-logo"><?php echo $_SESSION['tipo_usuario'];?></a>
        <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
        <ul id="nav-mobile" class="right hide-on-med-and-down lighten-2">
          <li class="page-scroll">
            <a href="./inicioAsesorado.php#/perfil/<?php echo $_SESSION['id']; ?>" > <?php echo "<img  src ='".$nombre1['foto']."' style='width: 30px; height: 30px; ' >";?>
            <span><?php echo $_SESSION['usuario'];?></span></a>
          </li>
          <li><a class="dropdown-button" href="#!" data-activates="foro">Foro</a></li>
          <li><a class="dropdown-button" href="#!" data-activates="contenido">Contenido</a></li>

          <li><a  href="./inicioAsesorado.php#/editor" data-activates="programar">Asesorias</a></li>
          <li><a href="../php/salir.php">Salir</a></li>

        </ul>
        <ul class="side-nav" id="mobile-demo">
          <li><div class="userView">
            <div class="background">
              <img src="../img/fondo_perfil.jpg">
            </div>
            <a class="close white"><i class="large material-icons red-text text-darken-4">skip_previous</i></a>
            <a href="#perfil/<?php echo $_SESSION['id']; ?>"><img class="circle" ng-src="{{usuario.foto}}"></a>
            <a href="#perfil/<?php echo $_SESSION['id']; ?>"><span class="white-text name">{{usuario.usuario}}</span></a>
          </div></li>
               <li class="no-padding">
                 <ul class="collapsible collapsible-accordion">
                   <li>
                     <a class="collapsible-header blue-text text-darken-2">Foro</a>
                     <div class="collapsible-body">
                       <ul>
                         <li><a href="./inicioAsesorado.php#/foro/java" class="blue-text text-darken-4">Java</a></li>
                         <li><a href="./inicioAsesorado.php#/foro/c" class="blue-text text-darken-4">C</a></li>
                       </ul>
                     </div>
                   </li>
                 </ul>
               </li>
               <li><div class="divider blue darken-4"></div></li>
               <li class="no-padding">
                 <ul class="collapsible collapsible-accordion">
                   <li>
                     <a class="collapsible-header blue-text text-darken-2">Editor</a>
                     <div class="collapsible-body">
                       <ul>
                         <li><a href="#editor" class="blue-text text-darken-4">Java</a></li>
                         <li><a href="#editor" class="blue-text text-darken-4">C</a></li>
                       </ul>
                     </div>
                   </li>
                 </ul>
               </li>
               <li class="no-padding">
                 <ul class="collapsible collapsible-accordion">
              <li><div class="divider blue darken-4"></div></li>
                   <li>
                     <a class="collapsible-header blue-text text-darken-2">Contenido</a>
                     <div class="collapsible-body">
                       <ul>
                         <li><a class="waves-effect blue-text text-darken-4" href="ejercicios.php">Ejercicios</a></li>
                         <li><a class="waves-effect blue-text text-darken-4" href="multimedia.php">Multimedia</a></li>
                       </ul>
                     </div>
                   </li>
                 </ul>
               </li>
             </ul>

        </div>

        </nav>







      <div class="container"  style="  background-color:#29C5D6;" >
    <div>

           <div class="col-md-6 col-md-offset-3">
            <div class="text-center">
     <h4>Temario</h4>
      </div>
        </div>
    </div>
    </div>

 <div class="container-fluid">
  <div  class="col-md-12" name="tem" id="tem"  style="
height: 500px;
overflow:scroll;
overflow-x: hidden;
visibility: visible;
" >

  </div>


</div>

   <!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Descricion</h4>
      </div>
      <div class="modal-body">
          <div style=""  class="col-md-12 col-md visible-desktop text-center" name="des" id="des" >


    </div>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
<div  class="container ">
    <div class="col-md-6 col-md-offset-3">
            <div class="text-center">
        <form id="BA" name="BA" method="post" accept-charset="utf-8">
      <div class="form-group">
      <label for="exampleInputFile">Buscar archivo</label>
       <input id="Nombrea" name="Nombrea" type="text" placeholder="Nombre del archivo" class="form-control">
       <br/>
<br/>
<button id="Buscar" type="submit" name="Buscar"  <?php echo 'onclick="buscar('.$_SESSION['id'].')"'; ?> value="Buscar" class="btn btn-primary btn-lg" ;>Buscar</button>
    </form>
        </div>
         </div>
</div>
<div class="container-fluid">
  <div  class="col-md-12" name="busqueda" id="busqueda"  style="
height: 200px;
overflow:scroll;
overflow-x: hidden;
visibility: visible;
" >

  </div>

</div>
   <br/><br/><br/>

    <br/><br/><br/>


      <!-- Footer -->
        <footer class="page-footer blue darken-2">
                  <div class="container">
                    <div class="row">
                      <div class="col l6 s12">
                        <h5 class="white-text">Asesorías en Linea para la UPIIZ-IPN</h5>
                        <p class="grey-text text-lighten-4">Plataforma web para  Asesorías de Programación en C y en Java</p>
                      </div>
                      <div class="col l4 offset-l2 s12">
                        <h5 class="white-text"></h5>
                        <ul>
                          <li><a class="grey-text text-lighten-3" href="#!"></a></li>
                          <li><a class="grey-text text-lighten-3" href="#!"></a></li>
                          <li><a class="grey-text text-lighten-3" href="#!"></a></li>
                          <li><a class="grey-text text-lighten-3" href="#!"></a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="footer-copyright blue darken-4">
                    <div class="container">
                    © 2014 Copyright Text
                    <a class="grey-text text-lighten-4 right" href="#!"></a>
                    </div>
                  </div>
                </footer>
        <!-- jQuery -->
        <script src="../js/jquery/jquery.min.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>
        <!-- Plugin JavaScript -->
        <script src="../js/jquery.easing.min.js"></script>
        <!-- Contact Form JavaScript -->
        <script src="../js/jqBootstrapValidation.js"></script>
        <script src="../js/contact_me.js"></script>
        <!-- Theme JavaScript -->
        <script src="../js/freelancer.min.js"></script>
        <script src="../js/moment/moment.min.js"></script>
        <script src="../js/ng-table.min.js"></script>
        <script src="../js/jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="../bower_components/ace-builds/src-min-noconflict/ace.js"></script>
        <script type="text/javascript" src="../bower_components/angular/angular.js"></script>
        <script type="text/javascript" src="../bower_components/angular-ui-ace/ui-ace.js"></script>
        <script type="text/javascript" src="../bower_components/ace-builds/src-min-noconflict/ext-language_tools.js"></script>
        <script src="../js/angular.min.js"></script>
        <script src="../js/angular-route.min.js"></script>
        <script src="../js/moment/moment.min.js"></script>
        <script src="../js/moment/angular-moment.js"></script>
        <script src="../css/js/materialize.min.js"></script>
        <script src="../js/firebase.js"></script>
        <script src="../js/angularfire.min.js"></script>
        <script src="../app/controllerAdministrador.js"></script>
        <script src="../app/controllerForo.js"></script>
        <script src="../app/controllerEditor.js"></script>
        <script src="../app/controllerChat.js"></script>
        <script src="../app/controllerPerfil.js"></script>
        <script>
        $( document ).ready(function(){$(".button-collapse").sideNav(); $(".dropdown-button").dropdown();
        $( ".close" ).click(function() {
         $('.button-collapse').sideNav('hide');});
        });

        </script>
        <script src="../app/app.js"></script>
