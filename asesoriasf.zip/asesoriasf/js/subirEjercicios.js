$( document ).ready(function()
{

	var msj = $(".upload-msg");

	$("#ejercicios").on("submit", function(e){
		e.preventDefault();
		var archivo = document.getElementById("archivo").files;
		if(archivo.length!=0){
			if (archivo[0].size > 8388608  ) {
				document.getElementById("ejercicios").reset();
				var a='<div class="alert alert-danger alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong>Error el documento es demasiado grande!</strong>'
				msj.html(a);
				window.setTimeout(function() {
				$(".alert-dismissible").fadeTo(500, 0).slideUp(500, function(){
				$(this).remove();
				}); }, 5000);
			}else {
			  var nom = archivo[0].name;

				if (nom.length > 200  ) {
					document.getElementById("ejercicios").reset();
					var a='<div class="alert alert-danger alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong>Error el nombre del documento demasiado grande!</strong>'

					msj.html(a);
					window.setTimeout(function() {
					$(".alert-dismissible").fadeTo(500, 0).slideUp(500, function(){
					$(this).remove();
					}); }, 5000);
				}else{
						var formData = new FormData(document.getElementById("ejercicios"));
						$.ajax({
							url: "../php/agregarEjercicios.php",
							type: "POST",
							dataType: "HTML",
							data: formData,
							cache: false,
							contentType: false,
							processData: false
						}).done(function(echo){
							msj.html(echo);
							document.getElementById("ejercicios").reset();
							var dataDecodificados = JSON.parse(echo);
							if (dataDecodificados.estatus == 1) {
								var respuesta= dataDecodificados.mensaje;
								var a='<div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong>'+respuesta+'</strong>'
								msj.html(a);
					            window.setTimeout(function() {
					            $(".alert-dismissible").fadeTo(500, 0).slideUp(500, function(){
					            $(this).remove();
					            }); }, 5000);

							}else{
								//document.getElementById("ejercicios").reset();
								var error = dataDecodificados.mensaje;
								var a='<div class="alert alert-danger alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong>'+error+'</strong>'

								msj.html(a);
								window.setTimeout(function() {
								$(".alert-dismissible").fadeTo(500, 0).slideUp(500, function(){
								$(this).remove();
								}); }, 5000);
								document.getElementById("ejercicios").reset();

							}
						});
				}
			}
		}
	});
});
