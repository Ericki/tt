var app = angular.module('myApp', ['ngRoute','angularMoment','ngTable','ui.bootstrap','ui.ace','firebase','Administrador','Chat','Perfil','Foro','Editor']);
app.factory("services", ['$http', function($http) {
  var serviceBase = '../services/'
    var obj = {};
    obj.getCustomers = function(){return $http.get(serviceBase + 'customers');}
    obj.getUsuarios = function(){return $http.get(serviceBase + 'usuarios');}
    obj.insertAsesorias = function (customer) {return $http.post(serviceBase + 'crearAsesorias', customer).then(function (results) {return results;});};
    obj.getCustomer = function(customerID){return $http.get(serviceBase + 'customer?id=' + customerID);}
    obj.insertCustomer = function (customer) {return $http.post(serviceBase + 'insertCustomer', customer).then(function (results) {return results;});};
	  obj.updateCustomer = function (id,customer) {return $http.post(serviceBase + 'updateCustomer', {id:id, customer:customer}).then(function (status) {return status.data;});};
	  obj.deleteCustomer = function (id) {return $http.delete(serviceBase + 'deleteCustomer?id=' + id).then(function (status) {return status.data;});};
    obj.getComentarios = function(lenguaje){return $http.get(serviceBase + 'comentarios?lenguaje=' + lenguaje);}
    obj.getComentariosC = function(){return $http.get(serviceBase + 'comentariosC');}
    obj.getComentario = function(comentarioID){return $http.get(serviceBase + 'comentario?id=' + comentarioID);}
    obj.insertarComentario = function (comentario) {return $http.post(serviceBase + 'insertarComentario', comentario).then(function (results) {return results;});};
    obj.actualizarComentario = function (id,customer) {return $http.post(serviceBase + 'actualizarComentario', {id:id, customer:customer}).then(function (status) {return status.data;});};
    obj.borrarComentario = function (id) {return $http.delete(serviceBase + 'borrarComentario?id=' + id).then(function (status) {return status.data;});};
    obj.getSubComentarios = function(){return $http.get(serviceBase + 'subComentarios');}
    obj.getSubComentario = function(comentarioID){return $http.get(serviceBase + 'subComentario?id=' + comentarioID);}
    obj.insertarSubComentario = function (comentario) {return $http.post(serviceBase + 'insertarSubComentario', comentario).then(function (results) {return results;});};
    obj.actualizarSubComentario = function (id,customer) {return $http.post(serviceBase + 'actualizarSubComentario', {id:id, customer:customer}).then(function (status) {return status.data;});};
    obj.borrarSubComentario = function (id) {return $http.delete(serviceBase + 'borrarSubComentario?id=' + id).then(function (status) {return status.data;});};
    obj.getMensajesChat = function(conversacionID){return $http.get(serviceBase + 'mensajesChat?id='+conversacionID );}
    obj.insertarMensaje = function (mensaje) {return $http.post(serviceBase + 'insertMensaje', mensaje).then(function (results) {return results;});};
    obj.getMensaje = function(conversacionID){return $http.get(serviceBase + 'mensaje?id=' + conversacionID);}
    obj.getAsesorias = function(){return $http.get(serviceBase + 'asesorias');}
    return obj;
}]);

app.controller('usuarioEditCtrl', function ($scope, $rootScope, $location, $routeParams, services, customer, upload) {
    var customerID = ($routeParams.customerID) ? parseInt($routeParams.customerID) : 0;
    $rootScope.title = (customerID > 0) ? 'Editar Usuario' : 'Añadir usuario';
    $scope.buttonText = (customerID > 0) ? 'Actualizar' : 'Añadir nuevo usuario';
      var original = customer.data;original._id = customerID;$scope.customer = angular.copy(original);$scope.customer._id = customerID;

    $scope.uploadFile = function(customer){var name = $scope.name;var file = $scope.file;
      upload.uploadFile(file, name).then(function(res){
      $scope.customer.foto= '../php/imagenes/'+res.data;
      console.log("estos son los datos"+res.data)

      $location.path('/editar-perfil/'+customerID);
      });
      services.updateCustomer($scope.customer._id, $scope.customer);
      console.log($scope.customer._id)
      console.log($scope.customer);
      $window.location.reload();
    };
      $scope.isClean = function() {return angular.equals(original, $scope.customer);}
      $scope.deleteCustomer = function(customer) {$location.path('/');if(confirm("Seguro eliminar: "+$scope.customer._id)==true)services.deleteCustomer(customer.id_usuario);};
      $scope.saveCustomer = function(customer) {$location.path('/');if (customerID <= 0) {services.insertCustomer(customer);}else {services.updateCustomer(customerID, customer);$location.path("/perfil/"+customerID);}};
      $scope.status = ['Alta','Baja'];$scope.selected = $scope.status[0];
});
app.controller('editCtrl', function ($scope, $rootScope, $location, $routeParams, services, customer) {
    var customerID = ($routeParams.customerID) ? parseInt($routeParams.customerID) : 0;
    $rootScope.title = (customerID > 0) ? 'Editar Usuario' : 'Añadir usuario';
    $scope.buttonText = (customerID > 0) ? 'Actualizar' : 'Añadir nuevo usuario';
      var original = customer.data;
      original._id = customerID;
      $scope.customer = angular.copy(original);
      $scope.customer._id = customerID;
      $scope.isClean = function() {
        return angular.equals(original, $scope.customer);
      }

      $scope.deleteCustomer = function(customer) {
        if(confirm("Seguro: "+$scope.customer._id)==true)
        services.deleteCustomer(customer.id_usuario);
        $location.path('/administrar-usuarios-asesor');
      };

      $scope.saveCustomer = function(customer) {
        if (customerID <= 0) {
            services.insertCustomer(customer);
        }
        else {
            services.updateCustomer(customerID, customer);
            $location.path('/administrar-usuarios-asesor');

        }
    };

     $scope.status = ['Alta','Baja'];
     $scope.tusuarios = ['Asesorado','Alumno Asesor','Asesor'];
     $scope.selected2 = $scope.tusuarios[0];
     $scope.selected = $scope.status[0];
});
app.controller('listaComentariosCtrl', function ($scope, services,moment, $rootScope, $location, $routeParams, customer) {
  var lenguaje = ($routeParams.lenguaje);$scope.lenguaje=lenguaje;
//  alert($scope.lenguaje);
    services.getComentarios(lenguaje).then(function(data){
        $scope.comentarios = data.data;$scope.filteredComentario = [],$scope.currentPage = 1,$scope.numPerPage = 5,$scope.maxSize = 5;
    $scope.makeTodos = function() {$scope.todos = [];$scope.todos=data.data;};
    $scope.makeTodos();
    $scope.numPages = function () {return Math.ceil($scope.todos.length / $scope.numPerPage);};
    $scope.$watch('currentPage + numPerPage', function() {
      var begin = (($scope.currentPage - 1) * $scope.numPerPage), end = begin + $scope.numPerPage;
      $scope.filteredComentario = $scope.todos.slice(begin, end);
    });
    });

    services.getSubComentarios().then(function(data){$scope.subComentarios = data.data;});
    angular.element(document).ready(function () {$('.collapsible').collapsible();});

});

app.controller('editarComentarioCtrl', function ($scope, $rootScope, $location, $routeParams, services, customer) {
    var customerID = ($routeParams.customerID) ? parseInt($routeParams.customerID) : 0;var lenguaje = ($routeParams.lenguaje);$scope.lenguaje = lenguaje;
    //alert($scope.lenguaje);
    $rootScope.title = (customerID > 0) ? 'Editar Comentario' : 'Añadir Comentario';
    $scope.buttonText = (customerID > 0) ? 'Editar' : 'Comentar';
      var original = customer.data;
      original._id = customerID;
      $scope.customer = angular.copy(original);
      $scope.customer._id = customerID;
      $scope.isClean = function() {return angular.equals(original, $scope.customer);}
      $scope.deleteCustomer = function(customer) {if(confirm("Borrar comentario: "+$scope.customer._id)==true)services.borrarComentario(customer.id_foro);$location.path("/foro/"+lenguaje);};
      $scope.saveCustomer = function(customer) {if (customerID <= 0) {services.insertarComentario(customer);$location.path("/foro/"+lenguaje);}else {services.actualizarComentario(customerID, customer);$location.path("/foro/"+lenguaje);}
    };
    var f = new Date();
    $scope.message = {time:  f.getFullYear()+ "-" + (f.getMonth() +1) + "-" + f.getDate() + " " + f.getHours()+ ":" +f.getMinutes()+ ":"+f.getSeconds()};
});
app.controller('insertarSubComentarioCtrl', function ($scope, $rootScope, $location, $routeParams, services, customer) {
    var customerID = ($routeParams.customerID) ? parseInt($routeParams.customerID) : 0;
    var lenguaje = ($routeParams.lenguaje);
    $scope.lenguaje = lenguaje;
  //  alert($scope.lenguaje);
    $rootScope.title = (customerID > 0) ? 'Comentar' : 'Añadir Comentario';
    $scope.buttonText = (customerID > 0) ? 'Comentar' : 'Comentar';
      var original = customer.data;
      original._id = customerID;
      $scope.customer = angular.copy(original);
      $scope.customer._id = customerID;
      $scope.isClean = function() {return angular.equals(original, $scope.customer);}
      $scope.saveCustomer = function(customer) {services.insertarSubComentario (customer);$location.path("/foro/"+lenguaje);};
    var f = new Date();
    $scope.message = {time:  f.getFullYear()+ "-" + (f.getMonth() +1) + "-" + f.getDate() + " " + f.getHours()+ ":" +f.getMinutes()+ ":"+f.getSeconds()};
});

app.controller('editarSubComentarioCtrl', function ($scope, $rootScope, $location, $routeParams, services, customer) {
  var lenguaje = ($routeParams.lenguaje);
  $scope.lenguaje = lenguaje;
//  alert($scope.lenguaje);
    var customerID = ($routeParams.customerID) ? parseInt($routeParams.customerID) : 0;
    $rootScope.title = (customerID > 0) ? 'Editar Comentario' : 'Añadir Comentario';
    $scope.buttonText = (customerID > 0) ? 'Editar' : 'Comentar';
      var original = customer.data;
      original._id = customerID;
      $scope.customer = angular.copy(original);
      $scope.customer._id = customerID;
      $scope.isClean = function() {return angular.equals(original, $scope.customer);}
      $scope.deleteCustomer = function(customer) {if(confirm("Borrar comentario: "+$scope.customer._id)==true)services.borrarSubComentario(customer.id_comentario);$location.path("/foro/"+lenguaje);};
      $scope.saveCustomer = function(customer) {$location.path('/');if (customerID <= 0) {services.insertarSubComentario(customer);$location.path("/foro/"+lenguaje);}else {services.actualizarSubComentario(customerID, customer);$location.path("/foro/"+lenguaje);}};
    var f = new Date();
    $scope.message = {time:  f.getFullYear()+ "-" + (f.getMonth() +1) + "-" + f.getDate() + " " + f.getHours()+ ":" +f.getMinutes()+ ":"+f.getSeconds()};
});
app.controller('HomeCtrl', ['$scope', 'upload', function ($scope, upload){
  $scope.uploadFile = function(){var name = $scope.name;var file = $scope.file;
    upload.uploadFile(file, name).then(function(res){
      console.log('nombre de la foto'+res);
    })}}])

app.directive('uploaderModel', ["$parse", function ($parse) {
  return {restrict: 'A',link: function (scope, iElement, iAttrs){iElement.on("change", function(e){$parse(iAttrs.uploaderModel).assign(scope, iElement[0].files[0]);});}};}])

app.service('upload', ["$http", "$q", function ($http, $q){
  this.uploadFile = function(file, name){var deferred = $q.defer();
    var formData = new FormData();
    formData.append("name", name);
    formData.append("file", file);
    return $http.post("../php/server.php", formData, {
      headers: {"Content-type": undefined},transformRequest: angular.identity})
    .success(function(res){deferred.resolve(res);})
    .error(function(msg, code){deferred.reject(msg);})
    return deferred.promise;}}])




app.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider
    .when('/', {title: 'Inicio',templateUrl: '../partials/inicio.php',controller: 'TestCtrl'})
    .when('/perfil/:customerID', {title: 'Perfil',templateUrl: '../partials/perfil/perfil.php',controller: 'usuarioEditCtrl',
    resolve: {customer: function(services, $route){var customerID = $route.current.params.customerID;return services.getCustomer(customerID);}}})
      .when('/editar-perfil/:customerID', {title: 'Editar Perfil',templateUrl: '../partials/perfil/editar-perfil.php',controller: 'usuarioEditCtrl',
    resolve: {customer: function(services, $route){var customerID = $route.current.params.customerID;return services.getCustomer(customerID);}}})
    .when('/administrar-usuarios', {title: 'Administrar usuarios',templateUrl: '../partials/administrador/administrar-usuarios.php',controller: 'listCtrl'})
      .when('/administrar-usuarios-asesor', {title: 'Administrar usuarios',templateUrl: '../partials/administrador/administrar-usuarios-asesor.php',controller: 'listUsuariosCtrl'})
      .when('/foro/:lenguaje', {title: 'Foro',templateUrl: '../partials/foro/comentarios.php',controller: 'listaComentariosCtrl',
    resolve: {customer: function(services, $route){var lenguaje = $route.current.params.lenguaje;}}})
    .when('/editar-comentario/:lenguaje/:customerID', {title: 'Editar Comentario',templateUrl: '../partials/foro/editar-comentario.php',controller: 'editarComentarioCtrl',
    resolve: {customer: function(services, $route){var comentarioID = $route.current.params.customerID;var lenguaje = $route.current.params.lenguaje;return services.getComentario(comentarioID);}}})
  .when('/insertar-subcomentario/:lenguaje/:customerID', {title: 'Editar Comentario',templateUrl: '../partials/foro/insertar-subcomentario.php',controller: 'insertarSubComentarioCtrl',
    resolve: {customer: function(services, $route){var comentarioID = $route.current.params.customerID;var lenguaje = $route.current.params.lenguaje;return services.getComentario(comentarioID);}}})
  .when('/editar-subcomentario/:lenguaje/:customerID', {title: 'Editar Comentario',templateUrl: '../partials/foro/editar-subcomentario.php',controller: 'editarSubComentarioCtrl',
    resolve: {customer: function(services, $route){var comentarioID = $route.current.params.customerID;var lenguaje = $route.current.params.lenguaje;return services.getSubComentario(comentarioID);}}})
    .when('/editor', {title: 'Asesorias',templateUrl: '../partials/editor/editor.php',controller: 'AceCtrl',resolve: {}})
    .when('/asesorias-asesor', {title: 'Asesorias',templateUrl: '../partials/editor/editor.php',controller: 'AceCtrl',resolve: {}})
    .when('/asesorias-asesorado', {title: 'Asesorias',templateUrl: '../partials/editor/editor.php',controller: 'AceCtrl',resolve: {}})
    .when('/asesorias-alumno-asesor', {title: 'Asesorias',templateUrl: '../partials/editor/editor.php',controller: 'AceCtrl',resolve: {}})
    .when('/editar-usuario/:customerID', {title: 'Edit Customers',templateUrl: '../partials/administrador/editar-usuario.php',controller: 'editCtrl',
    resolve: {customer: function(services, $route){var customerID = $route.current.params.customerID;return services.getCustomer(customerID);}}})
    .when('/editar-usuario-asesor/:customerID', {title: 'Edit Customers',templateUrl: '../partials/administrador/editar-usuario-asesor.php',controller: 'editCtrl',
            resolve: {customer: function(services, $route){var customerID = $route.current.params.customerID;return services.getCustomer(customerID);}}})
    .when('/multimedia', {title: 'Multimedia',templateUrl: '../partials/multimedia/multimedia.php'})
    .when('/archivos', {title: 'Multimedia',templateUrl: '../partials/archivos/archivos.php'})

    .otherwise({redirectTo: '/'});
}]);
app.run(['$location', '$rootScope', function($location, $rootScope) {
    $rootScope.$on('$routeChangeSuccess', function (event, current, previous) {
        $rootScope.title = current.$$route.title;
    });
}]);
