var foro = angular.module("Foro", []);
foro.factory("services", ['$http', function($http) {
  var serviceBase = '../services/'
  var obj = {};
    obj.getCustomers = function(){return $http.get(serviceBase + 'customers');}
    obj.getUsuarios = function(){return $http.get(serviceBase + 'usuarios');}
    obj.getCustomer = function(customerID){
        return $http.get(serviceBase + 'customer?id=' + customerID);
    }

    obj.insertCustomer = function (customer) {
    return $http.post(serviceBase + 'insertCustomer', customer).then(function (results) {
        return results;
    });
	  };

	  obj.updateCustomer = function (id,customer) {
	    return $http.post(serviceBase + 'updateCustomer', {id:id, customer:customer}).then(function (status) {
	        return status.data;
	    });
	};

	obj.deleteCustomer = function (id) {
	    return $http.delete(serviceBase + 'deleteCustomer?id=' + id).then(function (status) {
	        return status.data;
	    });
	};
  obj.getComentarios = function(lenguaje){
        return $http.get(serviceBase + 'comentarios?lenguaje=' + lenguaje);
    }
    obj.getComentariosC = function(){
        return $http.get(serviceBase + 'comentariosC');
    }
    obj.getComentario = function(comentarioID){
        return $http.get(serviceBase + 'comentario?id=' + comentarioID);
    }

    obj.insertarComentario = function (comentario) {
    return $http.post(serviceBase + 'insertarComentario', comentario).then(function (results) {
        return results;
    });
    };

  obj.actualizarComentario = function (id,customer) {
      return $http.post(serviceBase + 'actualizarComentario', {id:id, customer:customer}).then(function (status) {
          return status.data;
      });
  };
obj.borrarComentario = function (id) {
      return $http.delete(serviceBase + 'borrarComentario?id=' + id).then(function (status) {
          return status.data;
      });
  };
  obj.getSubComentarios = function(){
        return $http.get(serviceBase + 'subComentarios');
    }
  obj.getSubComentario = function(comentarioID){
        return $http.get(serviceBase + 'subComentario?id=' + comentarioID);
  }

  obj.insertarSubComentario = function (comentario) {
    return $http.post(serviceBase + 'insertarSubComentario', comentario).then(function (results) {
        return results;
  });
  };
  obj.actualizarSubComentario = function (id,customer) {
      return $http.post(serviceBase + 'actualizarSubComentario', {id:id, customer:customer}).then(function (status) {
          return status.data;
      });
  };
 obj.borrarSubComentario = function (id) {
      return $http.delete(serviceBase + 'borrarSubComentario?id=' + id).then(function (status) {
          return status.data;
      });
  };
  obj.getMensajesChat = function(conversacionID){
      return $http.get(serviceBase + 'mensajesChat?id='+conversacionID );
  }
  obj.insertarMensaje = function (mensaje) {
    return $http.post(serviceBase + 'insertMensaje', mensaje).then(function (results) {
        return results;
  });
  };
  obj.getMensaje = function(conversacionID){
      return $http.get(serviceBase + 'mensaje?id=' + conversacionID);
  }

    return obj;

}]);

//foro.controller('TestCtrl', function($scope) {alert('FOrot perros');});
