//Programa de asesorias Adrian
// Clase principal iniciadora del programa ejemplo aprenderaprogramar.com
public class Adrian {
public static void main (String [ ] args) {
    int x=0;
//Aquí las instrucciones de inicio y control del programa
System.out.println ("Erick");
System.out.println ("no es gay");
System.out.println ("es gay");
System.out.println ("es super gay, super super ");

System.out.println (x+x);
System.out.println (x+x);
System.out.println (x+x);
System.out.println (x+x);
System.out.println (x+x);
System.out.println (x+x);

            
//jjjjjjjjjjddddddddddddddddddddddddddddjjjjvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvjjjjjjjjjjjjjjjjjjj
} //Cierre del main
} //Cierre de la clase'; 