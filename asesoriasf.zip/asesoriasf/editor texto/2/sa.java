// Clase principal iniciadora del programa ejemplo aprenderaprogramar.com

public class sa {

    public static void main (String [ ] args) {

 

        //Aquí las instrucciones de inicio y control del programa

 
        for(int i =0; i<45; i++
        System.out.println (i+"Empezamos la ejecución del programa");

 

    } //Cierre del main

} //Cierre de la clase