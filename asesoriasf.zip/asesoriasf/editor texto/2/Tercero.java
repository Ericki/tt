//Programa de asesorias Tercero
// Clase principal iniciadora del programa ejemplo en java
public class Tercero {
public static void main (String [ ] args) {
//Aquí las instrucciones de inicio y control del programa

for(int i =0;i<10;i++)
System.out.println (" el contador i es igual a "+i);

    
} //Cierre del main
} //Cierre de la clase';