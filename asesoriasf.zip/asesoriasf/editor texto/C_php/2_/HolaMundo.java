public class HolaMundo {
public int hola(){
 System.out.println("Hola jijiji si");
System.out.println("Hola jijiji adrian ");
return 6;
   }
}