public class Caro {
public static void main(String[] args) { 

