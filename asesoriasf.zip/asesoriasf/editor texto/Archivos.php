 <?php
$var1 = $_POST['carpeta'];
foreach(glob($var1."/*") as $archivos_carpeta)

    {

$trozos = explode(".", $archivos_carpeta);
       $extension = end($trozos);
    if ($extension=="java") {
    $trozos = explode("/", $archivos_carpeta);
       $extension = end($trozos);
    $x=  str_replace($var1."/", "",$archivos_carpeta );
echo "<button  id =\"Abrir\"onClick=\"Abrir('".$x."');\" value=\"".$x."\">".$extension."</button>";
    echo "<br>";
    }

     }
     ?>
